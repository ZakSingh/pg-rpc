create view user_session(account_id, email, password_hash, access_token) as
select a.account_id, a.email, il.password_hash, el.access_token
from account a
         left join internal_login il using (email)
         left join external_login el using (account_id);

alter table user_session
    owner to postgres;

