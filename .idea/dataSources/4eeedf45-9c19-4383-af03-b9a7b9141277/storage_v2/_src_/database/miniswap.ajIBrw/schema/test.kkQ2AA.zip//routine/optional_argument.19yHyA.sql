create function optional_argument(required integer, opt_1 integer, opt_2 boolean) returns integer
    language plpgsql as
$$
begin
    return test.dep(required);
end;
$$;

alter function optional_argument(integer, integer, boolean) owner to postgres;

