create function create_password_reset(p_email text, p_reset_code text, p_reset_code_hash text, p_ip inet) returns void
    language plpgsql as
$$
declare
  v_email text;
begin
  -- Verify email exists and has internal login
  select il.email
  into strict v_email
  from internal_login il
  where il.email = p_email
    and il.deleted_at is null;

  -- Delete any pending password resets
  delete
  from password_reset
  where email = p_email
    and approved_at is null;

  -- Create new password reset
  insert into password_reset
    (email, reset_code_hash, requested_by_ip)
  values
    (p_email, p_reset_code_hash, p_ip);

  -- Queue password reset email
  insert into mq
    (queue, payload, max_attempts)
  values
    ('password_reset',
     json_build_object(
             'email', p_email,
             'code', p_reset_code
     ),
     5);

end;
$$;

alter function create_password_reset(text, text, text, inet) owner to postgres;

