create function ret_enum(p_account_id integer) returns currency_code
    language plpgsql as
$$
begin
    return 'us';
end
$$;

alter function ret_enum(integer) owner to postgres;

