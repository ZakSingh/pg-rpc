create function get_listing_by_id(p_listing_id integer) returns jsonb
    stable strict
    language plpgsql as
$$
begin
  return (
    select jsonb_build_object(
                   'listing_id', l.listing_id,
                   'price', l.price,
                   'created_at', l.created_at,
                   'updated_at', l.updated_at,
                   'is_published', l.is_published,
                   'quantity_remaining', (
                     select lqr.quantity_remaining
                     from views.listing_quantity_remaining lqr
                     where lqr.listing_id = p_listing_id
                   ),
                   'seller', (
                     select jsonb_build_object(
                                    'seller_id', s.seller_id,
                                    'rating', sr.rating_pct,
                                    'created_at', s.created_at
                            )
                     from seller s
                            left join views.seller_sales_count sc
                                      on sc.seller_id = s.seller_id
                            left join views.seller_rating_pct sr
                                      on sr.seller_id = sc.seller_id
                     where s.seller_id = l.seller_id
                   ),
                   'images', coalesce(
                           (
                             select jsonb_agg(
                                            jsonb_build_object(
                                                    'url', img.url,
                                                    'blurhash', img.blurhash
                                            )
                                            order by img.sort_order
                                    )
                             from public.listing_image img
                             where img.listing_id = l.listing_id
                           ), '[]'::JSONB)
           )
    from listing l
    where l.listing_id = p_listing_id
      and l.deleted_at is null
  );
end;
$$;

alter function get_listing_by_id(integer) owner to postgres;

