create function add_to_cart(p_account_id integer, p_listing_id integer) returns void
    language plpgsql as
$$
begin
  if not exists(
    select 1
    from views.active_listings
    where listing_id = p_listing_id
  ) then
    raise exception 'Listing % does not exist or is not available for purchase', p_listing_id
      using errcode = 'M0001';
  end if;

  -- Add to cart (or do nothing if already exists)
  insert into cart_listing
    (account_id, listing_id)
  values
    (p_account_id, p_listing_id)
  on conflict (account_id, listing_id) do nothing;
end;
$$;

alter function add_to_cart(integer, integer) owner to postgres;

