create function optional_test(a integer, b integer DEFAULT 1, c integer DEFAULT NULL::integer) returns integer
    language plpgsql as
$$
begin
    return b;
end;
$$;

alter function optional_test(integer, integer, integer) owner to postgres;

