create function ensure_seller_has_type() returns trigger
    language plpgsql
as
$$
begin
  if not exists (
    select 1
    from private_seller ps
    where ps.seller_id = NEW.seller_id
  ) and not exists (
    select 1
    from business_seller bs
    where bs.seller_id = NEW.seller_id
  ) then
    raise exception 'Seller ID % must have an associated private_seller or business_seller record', NEW.seller_id
      using errcode = 'M0031';
  end if;

  return NEW;
end;
$$;

alter function ensure_seller_has_type() owner to postgres;

