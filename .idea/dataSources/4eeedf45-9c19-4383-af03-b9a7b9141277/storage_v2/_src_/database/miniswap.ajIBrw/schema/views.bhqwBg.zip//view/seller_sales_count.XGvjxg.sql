create view seller_sales_count(seller_id, sales_count) as
select s.seller_id, coalesce(count(pl.*), 0::bigint) as sales_count
from seller s
         join listing l using (seller_id)
         join purchase_listing pl using (listing_id)
group by s.seller_id;

alter table seller_sales_count
    owner to postgres;

