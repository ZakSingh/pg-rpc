create function dep(i integer) returns integer
    language plpgsql as
$$
begin
    return i;
end;
$$;

alter function dep(integer) owner to postgres;

