create view post_with_author(post_id, author_id, content, author) as
select post.post_id,
       post.author_id,
       post.content,
       row (account.account_id, account.name, account.age, account.role)::test.account_not_null as author
from test.post
         left join test.account on post.author_id = account.account_id;

comment on column post_with_author.author is '@pgrpc_not_null';

alter table post_with_author
    owner to postgres;

