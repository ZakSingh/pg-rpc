create function prevent_last_item_soft_delete() returns trigger
    language plpgsql
as
$$
begin
  -- Check if the associated listing is published
  if exists (
    select 1
    from listing
    where listing_id = old.listing_id
      and is_published = true
      and not exists (
      select 1
      from listing_item
      where listing_id = old.listing_id
        and listing_item_id != old.listing_item_id
    )
  ) then
    -- Raise an exception if soft delete would leave no active items
    raise exception
      'Cannot delete the last active listing_item for a published listing (listing_id: %)',
      OLD.listing_id
      using errcode = 'M0006';
  end if;

  return OLD;
end;
$$;

alter function prevent_last_item_soft_delete() owner to postgres;

