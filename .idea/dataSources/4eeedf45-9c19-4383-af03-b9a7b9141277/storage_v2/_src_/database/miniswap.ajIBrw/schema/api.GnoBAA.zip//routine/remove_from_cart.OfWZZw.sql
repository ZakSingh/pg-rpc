create function remove_from_cart(p_account_id integer, p_listing_id integer) returns void
    language plpgsql as
$$
begin
  delete
  from cart_listing
  where account_id = p_account_id
    and listing_id = p_listing_id;
end;
$$;

alter function remove_from_cart(integer, integer) owner to postgres;

