create function check_listing_quantity_available() returns trigger
    language plpgsql
as
$$
declare
  v_quantity_remaining integer;
begin
  select quantity_remaining
  into v_quantity_remaining
  from listing_quantity_remaining
  where listing_id = NEW.listing_id;

  if v_quantity_remaining = 0 then
    raise exception 'Listing is no longer available'
      using errcode = 'M0016';
  end if;

  return NEW;
end;
$$;

alter function check_listing_quantity_available() owner to postgres;

