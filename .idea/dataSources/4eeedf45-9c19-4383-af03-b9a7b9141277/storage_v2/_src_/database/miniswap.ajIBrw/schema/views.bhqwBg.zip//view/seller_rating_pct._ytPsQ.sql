create view seller_rating_pct(seller_id, rating_pct) as
with rating_stats as ( select seller_feedback.seller_id,
                              count(seller_feedback.rating)                    as n,
                              coalesce(sum(seller_feedback.rating), 0::bigint) as sum_ratings
                       from views.seller_feedback
                       group by seller_feedback.seller_id )
select seller_id,
       least(greatest((5::numeric * 2.0 + sum_ratings::numeric) / (5 + n)::numeric * (100 / (3 - 1))::numeric,
                      0::numeric), 100::numeric) as rating_pct
from rating_stats rs;

alter table seller_rating_pct
    owner to postgres;

