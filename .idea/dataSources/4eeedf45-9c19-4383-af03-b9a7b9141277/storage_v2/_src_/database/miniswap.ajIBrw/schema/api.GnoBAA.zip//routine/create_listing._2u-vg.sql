create function create_listing(p_seller_id integer, p_price numeric, p_currency currency_code DEFAULT 'usd'::currency_code, p_country country_code DEFAULT 'us'::country_code, p_weight_g numeric DEFAULT NULL::numeric, p_length_cm numeric DEFAULT NULL::numeric, p_width_cm numeric DEFAULT NULL::numeric, p_height_cm numeric DEFAULT NULL::numeric, p_initial_quantity integer DEFAULT 1, p_description text DEFAULT NULL::text) returns jsonb
    language plpgsql as
$$
declare
  created_listing_id int;
begin
  insert into public.listing
    (seller_id,
     description,
     price,
     initial_quantity,
     weight_g,
     length_cm,
     width_cm,
     height_cm,
     country_code,
     currency)
  values
    (p_seller_id,
     p_description,
     p_price,
     p_initial_quantity,
     p_weight_g,
     p_length_cm,
     p_width_cm,
     p_height_cm,
     p_country,
     p_currency)
  returning listing_id into created_listing_id;

  return api.get_listing_by_id(created_listing_id);
end;
$$;

alter function create_listing(integer, numeric, currency_code, country_code, numeric, numeric, numeric, numeric, integer, text) owner to postgres;

