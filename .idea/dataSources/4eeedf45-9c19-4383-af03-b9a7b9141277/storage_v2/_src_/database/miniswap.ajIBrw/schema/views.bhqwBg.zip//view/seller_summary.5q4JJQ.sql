create view seller_summary
            (seller_id, stripe_account_id, shippo_account_id, created_at, updated_at, deleted_at, seller_type,
             display_name, sales_count, rating_pct)
as
select s.seller_id,
       s.stripe_account_id,
       s.shippo_account_id,
       s.created_at,
       s.updated_at,
       s.deleted_at,
       case when ps.seller_id is not null then 'private'::text else 'business'::text end                            as seller_type,
       case when ps.seller_id is not null then (a.first_name || ' '::text) || a.last_name
            else bs.business_name end                                                                               as display_name,
       sc.sales_count,
       rp.rating_pct
from seller s
         left join views.seller_sales_count sc using (seller_id)
         left join views.seller_rating_pct rp using (seller_id)
         left join private_seller ps on ps.seller_id = s.seller_id
         left join account a on a.account_id = ps.account_id
         left join business_seller bs on bs.seller_id = s.seller_id;

alter table seller_summary
    owner to postgres;

