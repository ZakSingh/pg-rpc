create view listing_quantity_remaining(listing_id, quantity_remaining) as
select l.listing_id, l.initial_quantity - coalesce(count(pl.*), 0::bigint) as quantity_remaining
from listing l
         left join purchase_listing pl using (listing_id)
group by l.listing_id, l.initial_quantity;

alter table listing_quantity_remaining
    owner to postgres;

