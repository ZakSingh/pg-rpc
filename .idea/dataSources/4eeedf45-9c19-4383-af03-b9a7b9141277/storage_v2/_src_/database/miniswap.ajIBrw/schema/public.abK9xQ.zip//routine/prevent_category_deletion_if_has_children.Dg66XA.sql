create function prevent_category_deletion_if_has_children() returns trigger
    language plpgsql
as
$$
begin
  -- Check if there are any child categories (categories whose path starts with the deleted category's path)
  if exists (
    select 1
    from category
    where path <@ OLD.path
      and nlevel(path) = nlevel(OLD.path) + 1
  ) then
    -- If child categories exist, raise an exception to prevent deletion
    raise exception 'Cannot delete category % because it has children', OLD.path
      using errcode = 'M0005';
  end if;

  -- If no child categories exist, allow the delete operation
  return OLD;
end;
$$;

alter function prevent_category_deletion_if_has_children() owner to postgres;

