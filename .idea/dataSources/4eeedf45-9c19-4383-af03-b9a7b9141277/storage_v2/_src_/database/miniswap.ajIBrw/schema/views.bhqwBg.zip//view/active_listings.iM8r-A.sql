create view active_listings
            (listing_id, seller_id, is_published, title, description, price, currency, country_code, initial_quantity,
             length_cm, width_cm, height_cm, weight_g, seller_pays_shipping, return_shipping_type, created_at,
             updated_at, deleted_at, quantity_remaining)
as
select l.listing_id,
       l.seller_id,
       l.is_published,
       l.title,
       l.description,
       l.price,
       l.currency,
       l.country_code,
       l.initial_quantity,
       l.length_cm,
       l.width_cm,
       l.height_cm,
       l.weight_g,
       l.seller_pays_shipping,
       l.return_shipping_type,
       l.created_at,
       l.updated_at,
       l.deleted_at,
       qr.quantity_remaining
from listing l
         join views.listing_quantity_remaining qr using (listing_id)
where l.is_published = true
  and l.deleted_at is null
  and qr.quantity_remaining > 0;

alter table active_listings
    owner to postgres;

