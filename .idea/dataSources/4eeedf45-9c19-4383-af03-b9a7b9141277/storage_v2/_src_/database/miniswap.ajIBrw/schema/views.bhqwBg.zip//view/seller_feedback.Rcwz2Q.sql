create view seller_feedback (seller_id, comment, rating, created_at, first_name, last_name, account_id) as
select l.seller_id,
       f.comment,
       f.rating,
       f.created_at,
       reviewer.first_name,
       reviewer.last_name,
       reviewer.account_id
from seller s
         join listing l on l.seller_id = s.seller_id
         join seller_feedback f on f.listing_id = l.listing_id
         join purchase p on p.purchase_id = f.purchase_id
         join account reviewer on p.account_id = reviewer.account_id
where f.deleted_at is null
  and reviewer.deleted_at is null;

alter table seller_feedback
    owner to postgres;

