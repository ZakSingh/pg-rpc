create function check_parent_exists() returns trigger
    language plpgsql
as
$$
declare
  parent_path ltree;
begin
  -- Extract the parent path by removing the last label from the ltree path
  -- If the path has only one level, we don't need to check the parent
  if nlevel(NEW.path) > 1 then
    -- Get the parent path
    parent_path := subpath(NEW.path, 0, nlevel(NEW.path) - 1);

    -- Check if the parent path exists
    if not exists (
      select 1
      from category
      where path = parent_path
    ) then
      raise exception 'Parent category % does not exist', parent_path
        using errcode = 'M0006';
    end if;
  end if;

  return NEW;
end;
$$;

alter function check_parent_exists() owner to postgres;

