create function prevent_duplicate_email() returns trigger
    language plpgsql
as
$$
begin
  if exists (
    select 1
    from internal_login
    where email = new.email
  ) then
    raise unique_violation using message =
            'An account with this email already exists';
  end if;
  return new;
end;
$$;

alter function prevent_duplicate_email() owner to postgres;

