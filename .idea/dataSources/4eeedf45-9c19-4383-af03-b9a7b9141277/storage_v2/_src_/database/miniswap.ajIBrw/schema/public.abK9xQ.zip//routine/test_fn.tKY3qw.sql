create function test_fn() returns test_comp
    language plpgsql as
$$
begin
    return row(1, 'two', '{3}'::int[])::test_comp;
end;
$$;

alter function test_fn() owner to postgres;

