create function update_display_path() returns trigger
    language plpgsql
as
$$
begin
  -- Build the display_path array by aggregating category names along the path
  select array_agg(c2.name order by nlevel(c2.path))
  into NEW.display_path
  from category as c2
  where c2.path @> subpath(NEW.path, 0, nlevel(c2.path));

  -- Add the current category's name at the end of the array
  NEW.display_path := coalesce(NEW.display_path, array []::text[]) || NEW.name;

  return NEW;
end;
$$;

alter function update_display_path() owner to postgres;

