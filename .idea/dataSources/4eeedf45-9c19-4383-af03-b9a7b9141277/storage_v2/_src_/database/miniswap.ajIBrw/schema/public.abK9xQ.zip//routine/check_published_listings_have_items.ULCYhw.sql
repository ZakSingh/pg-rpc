create function check_published_listings_have_items() returns trigger
    language plpgsql
as
$$
begin
  -- If is_published is being set to true
  if NEW.is_published = true then
    -- Check if there is at least one corresponding row in listing_item
    if not exists (
      select 1
      from listing_item
      where listing_item.listing_id = NEW.listing_id
    ) then
      -- Raise an exception if no matching rows exist
      raise exception
        'Cannot publish listing without associated listing_item rows'
        using errcode = 'M0005';
    end if;
  end if;
  
  -- Allow the update or insert
  return NEW;
end;
$$;

alter function check_published_listings_have_items() owner to postgres;

