create view jwt_claims(account_id, roles, country_code, suspended_privileges) as
select a.account_id, a.roles, a.country_code, array_agg(distinct t.type) as suspended_privileges
from account a
         left join suspension s on s.account_id = a.account_id and s.until > now()
         left join lateral unnest(s.suspended_privileges) t(type) on true
group by a.account_id, a.roles, a.country_code;

alter table jwt_claims
    owner to postgres;

