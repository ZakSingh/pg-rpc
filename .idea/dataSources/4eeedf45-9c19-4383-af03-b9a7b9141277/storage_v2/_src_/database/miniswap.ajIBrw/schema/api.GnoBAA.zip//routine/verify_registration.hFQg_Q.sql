create function verify_registration(p_email text, p_refresh_jti uuid, p_refresh_ip inet) returns integer
    strict
    language plpgsql as
$$
declare
  v_reg        record;
  v_account_id int;
  v_full_name  text;
begin

  delete
  from pending_registration
  where email = p_email
  returning * into v_reg;

  if v_reg is null then
    raise exception 'No pending registration with that email exists' using errcode = 'M0001';
  end if;

  insert into account
    (email, first_name, last_name)
  values
    (v_reg.email, v_reg.first_name, v_reg.last_name)
  on conflict (email) do update
    set updated_at = now()
  returning account_id, full_name
    into v_account_id, v_full_name;

  insert into internal_login
    (email, password_hash)
  values
    (v_reg.email, v_reg.password_hash);

  -- Store provided refresh token
  insert into refresh_token
    (jti, account_id, created_by_ip)
  values
    (p_refresh_jti, v_account_id, p_refresh_ip);

  perform functions.dispatch_create_stripe_customer(
          v_account_id,
          p_refresh_ip,
          v_reg.email,
          v_full_name);

  return v_account_id;
end;
$$;

alter function verify_registration(text, uuid, inet) owner to postgres;

