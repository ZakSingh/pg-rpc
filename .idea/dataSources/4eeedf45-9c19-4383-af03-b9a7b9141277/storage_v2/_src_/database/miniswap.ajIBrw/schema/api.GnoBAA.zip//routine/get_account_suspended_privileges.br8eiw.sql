create function get_account_suspended_privileges(p_account_id integer) returns suspension_privilege[]
    stable
    language sql as
$$
select array_agg(distinct t.type)
from suspension s,
     unnest(s.suspended_privileges) as t(type)
where s.account_id = p_account_id
  and s.until > now();
$$;

alter function get_account_suspended_privileges(integer) owner to postgres;

