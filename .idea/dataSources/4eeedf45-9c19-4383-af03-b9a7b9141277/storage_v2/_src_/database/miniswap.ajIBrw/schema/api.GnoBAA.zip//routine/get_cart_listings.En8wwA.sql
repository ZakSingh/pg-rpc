create function get_cart_listings(p_account_id integer)
    returns TABLE(listing_id integer, seller_id integer, price numeric, currency currency_code, quantity_remaining integer)
    stable
    language sql
as
$$
select l.listing_id,
       l.seller_id,
       l.price,
       l.currency,
       qr.quantity_remaining
from cart_listing cl
       join listing l on l.listing_id = cl.listing_id
       join views.listing_quantity_remaining qr on qr.listing_id = l.listing_id
where cl.account_id = p_account_id
  and l.is_published = true
  and l.deleted_at is null;
$$;

alter function get_cart_listings(integer) owner to postgres;

