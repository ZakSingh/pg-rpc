create function exchange_refresh_token(p_account_id integer, p_old_jti uuid, p_jti uuid, p_ip inet) returns views.jwt_claims
    language plpgsql as
$$
declare
  v_old_refresh_token refresh_token;
begin
  delete
  from refresh_token
  where jti = p_old_jti
  returning * into strict v_old_refresh_token;

  insert
    into refresh_token
    (jti, account_id, created_by_ip)
  values
    (p_jti, p_account_id, p_ip);

  return (
    select *
    from views.jwt_claims
    where account_id = p_account_id
  );
end;
$$;

alter function exchange_refresh_token(integer, uuid, uuid, inet) owner to postgres;

