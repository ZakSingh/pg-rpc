create function verify_password_reset(p_password_reset_id integer, p_password_hash text, p_refresh_jti uuid, p_ip inet) returns views.jwt_claims
    language plpgsql as
$$
declare
  v_account_id int;
  v_email      text;
begin
  -- Update password reset and get account info
  update password_reset pr
  set approved_at    = now(),
      approved_by_ip = p_ip
  where pr.password_reset_id = p_password_reset_id
    and pr.approved_at is null
    and pr.expires_at > now()
  returning email into v_email;

  if v_email is null then
    raise exception 'Invalid or expired password reset' using errcode = 'M0001';
  end if;

  -- Update password hash
  update internal_login
  set password_hash = p_password_hash,
      updated_at    = now()
  where email = v_email
  returning (
    select account_id
    from account
    where email = v_email
  )
    into v_account_id;

  if v_account_id is null then
    raise exception 'Account not found' using errcode = 'M0002';
  end if;

  -- Insert refresh token
  insert into refresh_token
    (jti, account_id, created_by_ip)
  values
    (p_refresh_jti, v_account_id, p_ip);

  -- Return JWT claims
  return (
    select *
    from views.jwt_claims
    where account_id = v_account_id
  );
end;
$$;

comment on function verify_password_reset(integer, text, uuid, inet) is '
  Verifies a password reset request, updates the user''s password, and creates a new
  refresh token.

  Parameters:
    p_password_reset_id - ID of the password reset request
    p_password_hash - New password hash to set
    p_refresh_jti - JWT UUID for the new refresh token
    p_ip - IP address of the verification request

  Returns:
    The JWT claims for the user''s new session

  Raises:
    22023 INVALID_PARAMETER_VALUE - Password reset is invalid, already used, or expired
    P0002 NO_DATA_FOUND - Account does not exist
';

alter function verify_password_reset(integer, text, uuid, inet) owner to postgres;

