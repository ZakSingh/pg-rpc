create function dispatch_create_stripe_customer(p_account_id integer, p_ip inet, p_email citext, p_full_name text) returns void
    strict
    language sql as
$$
insert into mq
  (queue, payload, max_attempts)
values
  ('create_stripe_customer',
   json_build_object(
           'account_id', p_account_id,
           'ip', p_ip,
           'email', p_email,
           'full_name', p_full_name), 5);
$$;

comment on function dispatch_create_stripe_customer(integer, inet, citext, text) is '
  Push an event to the message queue to create a new Stripe Customer.

  Parameters:
    p_account_id - The user''s account id
    p_ip - The user''s IP address upon signup, used for tax purposes by Stripe
    p_email - The user''s email address
    p_full_name - The full name of the user
';

alter function dispatch_create_stripe_customer(integer, inet, citext, text) owner to postgres;

