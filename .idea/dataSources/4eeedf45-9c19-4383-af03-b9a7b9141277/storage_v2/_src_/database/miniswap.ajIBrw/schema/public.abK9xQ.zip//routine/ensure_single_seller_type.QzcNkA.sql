create function ensure_single_seller_type() returns trigger
    language plpgsql
as
$$
begin
  if TG_TABLE_NAME = 'business_seller' and exists (
    select 1
    from private_seller ps
    where ps.seller_id = NEW.seller_id
  )
  then
    raise exception 'Seller ID % already exists as a private seller', NEW.seller_id
      using errcode = 'M0030';
  end if;

  if TG_TABLE_NAME = 'private_seller' and exists (
    select 1
    from business_seller bs
    where bs.seller_id = NEW.seller_id
  )
  then
    raise exception 'Seller ID % already exists as a business seller', NEW.seller_id
      using errcode = 'M0030';
  end if;

  return NEW;
end;
$$;

alter function ensure_single_seller_type() owner to postgres;

