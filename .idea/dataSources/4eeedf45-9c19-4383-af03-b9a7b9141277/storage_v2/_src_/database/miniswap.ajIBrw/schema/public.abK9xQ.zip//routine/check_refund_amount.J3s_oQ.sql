create function check_refund_amount() returns trigger
    language plpgsql
as
$$
declare
  total_refunded   numeric(10, 2);
  purchase_total   numeric(10, 2);
  remaining_amount numeric(10, 2);
begin
  total_refunded := coalesce(
          (
            select sum(amount)
            from purchase_listing_refund
            where purchase_id = NEW.purchase_id
              and listing_id = NEW.listing_id
          ), 0.00);

  purchase_total := coalesce(
          (
            select seller_amount + shipping_amount + tax_amount
            from purchase_listing
            where purchase_id = NEW.purchase_id
              and listing_id = NEW.listing_id
          ), 0.00);

  -- Calculate remaining amount that can be refunded
  remaining_amount := purchase_total - total_refunded;

  if NEW.amount > remaining_amount then
    raise exception 'Refund amount (%) would exceed remaining refundable amount (%) for purchase_id % listing_id %',
      NEW.amount, remaining_amount, NEW.purchase_id, NEW.listing_id
      using errcode = 'check_violation';
  end if;

  return NEW;
end;
$$;

alter function check_refund_amount() owner to postgres;

