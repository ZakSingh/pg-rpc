create view pg_statio_all_indexes (relid, indexrelid, schemaname, relname, indexrelname, idx_blks_read, idx_blks_hit) as
select c.oid                                                             as relid,
       i.oid                                                             as indexrelid,
       n.nspname                                                         as schemaname,
       c.relname,
       i.relname                                                         as indexrelname,
       pg_stat_get_blocks_fetched(i.oid) - pg_stat_get_blocks_hit(i.oid) as idx_blks_read,
       pg_stat_get_blocks_hit(i.oid)                                     as idx_blks_hit
from pg_class c
         join pg_index x on c.oid = x.indrelid
         join pg_class i on i.oid = x.indexrelid
         left join pg_namespace n on n.oid = c.relnamespace
where c.relkind = any (array ['r'::"char", 't'::"char", 'm'::"char"]);

alter table pg_statio_all_indexes
    owner to postgres;

grant select on pg_statio_all_indexes to public;

