create view view_column_usage
            (view_catalog, view_schema, view_name, table_catalog, table_schema, table_name, column_name) as
select distinct current_database()::information_schema.sql_identifier as view_catalog,
                nv.nspname::information_schema.sql_identifier         as view_schema,
                v.relname::information_schema.sql_identifier          as view_name,
                current_database()::information_schema.sql_identifier as table_catalog,
                nt.nspname::information_schema.sql_identifier         as table_schema,
                t.relname::information_schema.sql_identifier          as table_name,
                a.attname::information_schema.sql_identifier          as column_name
from pg_namespace nv,
     pg_class v,
     pg_depend dv,
     pg_depend dt,
     pg_class t,
     pg_namespace nt,
     pg_attribute a
where nv.oid = v.relnamespace
  and v.relkind = 'v'::"char"
  and v.oid = dv.refobjid
  and dv.refclassid = 'pg_class'::regclass::oid
  and dv.classid = 'pg_rewrite'::regclass::oid
  and dv.deptype = 'i'::"char"
  and dv.objid = dt.objid
  and dv.refobjid <> dt.refobjid
  and dt.classid = 'pg_rewrite'::regclass::oid
  and dt.refclassid = 'pg_class'::regclass::oid
  and dt.refobjid = t.oid
  and t.relnamespace = nt.oid
  and (t.relkind = any (array ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"]))
  and t.oid = a.attrelid
  and dt.refobjsubid = a.attnum
  and pg_has_role(t.relowner, 'USAGE'::text);

alter table view_column_usage
    owner to postgres;

grant select on view_column_usage to public;

