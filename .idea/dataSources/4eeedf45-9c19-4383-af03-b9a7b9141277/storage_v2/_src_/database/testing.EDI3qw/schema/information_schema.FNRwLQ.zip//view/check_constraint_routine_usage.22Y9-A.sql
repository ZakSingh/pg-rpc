create view check_constraint_routine_usage
            (constraint_catalog, constraint_schema, constraint_name, specific_catalog, specific_schema,
             specific_name) as
select distinct current_database()::information_schema.sql_identifier              as constraint_catalog,
                nc.nspname::information_schema.sql_identifier                      as constraint_schema,
                c.conname::information_schema.sql_identifier                       as constraint_name,
                current_database()::information_schema.sql_identifier              as specific_catalog,
                np.nspname::information_schema.sql_identifier                      as specific_schema,
                nameconcatoid(p.proname, p.oid)::information_schema.sql_identifier as specific_name
from pg_namespace nc,
     pg_constraint c,
     pg_depend d,
     pg_proc p,
     pg_namespace np
where nc.oid = c.connamespace
  and c.contype = 'c'::"char"
  and c.oid = d.objid
  and d.classid = 'pg_constraint'::regclass::oid
  and d.refobjid = p.oid
  and d.refclassid = 'pg_proc'::regclass::oid
  and p.pronamespace = np.oid
  and pg_has_role(p.proowner, 'USAGE'::text);

alter table check_constraint_routine_usage
    owner to postgres;

grant select on check_constraint_routine_usage to public;

