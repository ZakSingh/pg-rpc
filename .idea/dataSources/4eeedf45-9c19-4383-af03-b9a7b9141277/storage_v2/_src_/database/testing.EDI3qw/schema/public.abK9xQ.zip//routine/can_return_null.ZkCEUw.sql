create function can_return_null() returns integer
    language sql as
$$
SELECT null::int;
$$;

alter function can_return_null() owner to postgres;

