create view transforms
            (udt_catalog, udt_schema, udt_name, specific_catalog, specific_schema, specific_name, group_name,
             transform_type) as
select current_database()::information_schema.sql_identifier              as udt_catalog,
       nt.nspname::information_schema.sql_identifier                      as udt_schema,
       t.typname::information_schema.sql_identifier                       as udt_name,
       current_database()::information_schema.sql_identifier              as specific_catalog,
       np.nspname::information_schema.sql_identifier                      as specific_schema,
       nameconcatoid(p.proname, p.oid)::information_schema.sql_identifier as specific_name,
       l.lanname::information_schema.sql_identifier                       as group_name,
       'FROM SQL'::character varying::information_schema.character_data   as transform_type
from pg_type t
         join pg_transform x on t.oid = x.trftype
         join pg_language l on x.trflang = l.oid
         join pg_proc p on x.trffromsql::oid = p.oid
         join pg_namespace nt on t.typnamespace = nt.oid
         join pg_namespace np on p.pronamespace = np.oid
union
select current_database()::information_schema.sql_identifier              as udt_catalog,
       nt.nspname::information_schema.sql_identifier                      as udt_schema,
       t.typname::information_schema.sql_identifier                       as udt_name,
       current_database()::information_schema.sql_identifier              as specific_catalog,
       np.nspname::information_schema.sql_identifier                      as specific_schema,
       nameconcatoid(p.proname, p.oid)::information_schema.sql_identifier as specific_name,
       l.lanname::information_schema.sql_identifier                       as group_name,
       'TO SQL'::character varying::information_schema.character_data     as transform_type
from pg_type t
         join pg_transform x on t.oid = x.trftype
         join pg_language l on x.trflang = l.oid
         join pg_proc p on x.trftosql::oid = p.oid
         join pg_namespace nt on t.typnamespace = nt.oid
         join pg_namespace np on p.pronamespace = np.oid
order by 1, 2, 3, 7, 8;

alter table transforms
    owner to postgres;

