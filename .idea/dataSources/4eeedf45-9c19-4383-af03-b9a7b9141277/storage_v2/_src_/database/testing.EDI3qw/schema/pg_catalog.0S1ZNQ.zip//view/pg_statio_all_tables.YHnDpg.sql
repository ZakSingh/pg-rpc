create view pg_statio_all_tables
            (relid, schemaname, relname, heap_blks_read, heap_blks_hit, idx_blks_read, idx_blks_hit, toast_blks_read,
             toast_blks_hit, tidx_blks_read, tidx_blks_hit)
as
select c.oid                                                             as relid,
       n.nspname                                                         as schemaname,
       c.relname,
       pg_stat_get_blocks_fetched(c.oid) - pg_stat_get_blocks_hit(c.oid) as heap_blks_read,
       pg_stat_get_blocks_hit(c.oid)                                     as heap_blks_hit,
       i.idx_blks_read,
       i.idx_blks_hit,
       pg_stat_get_blocks_fetched(t.oid) - pg_stat_get_blocks_hit(t.oid) as toast_blks_read,
       pg_stat_get_blocks_hit(t.oid)                                     as toast_blks_hit,
       x.idx_blks_read                                                   as tidx_blks_read,
       x.idx_blks_hit                                                    as tidx_blks_hit
from pg_class c
         left join pg_class t on c.reltoastrelid = t.oid
         left join pg_namespace n on n.oid = c.relnamespace
         left join lateral ( select sum(pg_stat_get_blocks_fetched(pg_index.indexrelid) -
                                        pg_stat_get_blocks_hit(pg_index.indexrelid))::bigint as idx_blks_read,
                                    sum(pg_stat_get_blocks_hit(pg_index.indexrelid))::bigint as idx_blks_hit
                             from pg_index
                             where pg_index.indrelid = c.oid) i on true
         left join lateral ( select sum(pg_stat_get_blocks_fetched(pg_index.indexrelid) -
                                        pg_stat_get_blocks_hit(pg_index.indexrelid))::bigint as idx_blks_read,
                                    sum(pg_stat_get_blocks_hit(pg_index.indexrelid))::bigint as idx_blks_hit
                             from pg_index
                             where pg_index.indrelid = t.oid) x on true
where c.relkind = any (array ['r'::"char", 't'::"char", 'm'::"char"]);

alter table pg_statio_all_tables
    owner to postgres;

grant select on pg_statio_all_tables to public;

