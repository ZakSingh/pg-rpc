create view views
            (table_catalog, table_schema, table_name, view_definition, check_option, is_updatable, is_insertable_into,
             is_trigger_updatable, is_trigger_deletable, is_trigger_insertable_into)
as
select current_database()::information_schema.sql_identifier         as table_catalog,
       nc.nspname::information_schema.sql_identifier                 as table_schema,
       c.relname::information_schema.sql_identifier                  as table_name,
       case when pg_has_role(c.relowner, 'USAGE'::text) then pg_get_viewdef(c.oid)
            else null::text end::information_schema.character_data   as view_definition,
       case when 'check_option=cascaded'::text = any (c.reloptions) then 'CASCADED'::text
            when 'check_option=local'::text = any (c.reloptions) then 'LOCAL'::text
            else 'NONE'::text end::information_schema.character_data as check_option,
       case when (pg_relation_is_updatable(c.oid::regclass, false) & 20) = 20 then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no        as is_updatable,
       case when (pg_relation_is_updatable(c.oid::regclass, false) & 8) = 8 then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no        as is_insertable_into,
       case when (exists ( select 1
                           from pg_trigger
                           where pg_trigger.tgrelid = c.oid and (pg_trigger.tgtype::integer & 81) = 81 )) then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no        as is_trigger_updatable,
       case when (exists ( select 1
                           from pg_trigger
                           where pg_trigger.tgrelid = c.oid and (pg_trigger.tgtype::integer & 73) = 73 )) then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no        as is_trigger_deletable,
       case when (exists ( select 1
                           from pg_trigger
                           where pg_trigger.tgrelid = c.oid and (pg_trigger.tgtype::integer & 69) = 69 )) then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no        as is_trigger_insertable_into
from pg_namespace nc,
     pg_class c
where c.relnamespace = nc.oid
  and c.relkind = 'v'::"char"
  and not pg_is_other_temp_schema(nc.oid)
  and (pg_has_role(c.relowner, 'USAGE'::text) or
       has_table_privilege(c.oid, 'SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::text) or
       has_any_column_privilege(c.oid, 'SELECT, INSERT, UPDATE, REFERENCES'::text));

alter table views
    owner to postgres;

grant select on views to public;

