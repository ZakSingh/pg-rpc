create function conditionally_returns_null(x integer) returns integer
    language sql as
$$
SELECT CASE WHEN x > 0 THEN x ELSE null END;
$$;

alter function conditionally_returns_null(integer) owner to postgres;

