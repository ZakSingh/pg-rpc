create function strict_test(p_account_id integer DEFAULT NULL::integer) returns integer
    language plpgsql as
$$
begin
    return 1;
end;
$$;

alter function strict_test(integer) owner to postgres;

