create view column_udt_usage
            (udt_catalog, udt_schema, udt_name, table_catalog, table_schema, table_name, column_name) as
select current_database()::information_schema.sql_identifier                as udt_catalog,
       coalesce(nbt.nspname, nt.nspname)::information_schema.sql_identifier as udt_schema,
       coalesce(bt.typname, t.typname)::information_schema.sql_identifier   as udt_name,
       current_database()::information_schema.sql_identifier                as table_catalog,
       nc.nspname::information_schema.sql_identifier                        as table_schema,
       c.relname::information_schema.sql_identifier                         as table_name,
       a.attname::information_schema.sql_identifier                         as column_name
from pg_attribute a,
     pg_class c,
     pg_namespace nc,
     pg_type t
         join pg_namespace nt on t.typnamespace = nt.oid
         left join ( pg_type bt join pg_namespace nbt on bt.typnamespace = nbt.oid )
                   on t.typtype = 'd'::"char" and t.typbasetype = bt.oid
where a.attrelid = c.oid
  and a.atttypid = t.oid
  and nc.oid = c.relnamespace
  and a.attnum > 0
  and not a.attisdropped
  and (c.relkind = any (array ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"]))
  and pg_has_role(coalesce(bt.typowner, t.typowner), 'USAGE'::text);

alter table column_udt_usage
    owner to postgres;

grant select on column_udt_usage to public;

