create view constraint_column_usage
            (table_catalog, table_schema, table_name, column_name, constraint_catalog, constraint_schema,
             constraint_name) as
select current_database()::information_schema.sql_identifier as table_catalog,
       tblschema::information_schema.sql_identifier          as table_schema,
       tblname::information_schema.sql_identifier            as table_name,
       colname::information_schema.sql_identifier            as column_name,
       current_database()::information_schema.sql_identifier as constraint_catalog,
       cstrschema::information_schema.sql_identifier         as constraint_schema,
       cstrname::information_schema.sql_identifier           as constraint_name
from ( select distinct nr.nspname, r.relname, r.relowner, a.attname, nc.nspname, c.conname
       from pg_namespace nr,
            pg_class r,
            pg_attribute a,
            pg_depend d,
            pg_namespace nc,
            pg_constraint c
       where nr.oid = r.relnamespace
         and r.oid = a.attrelid
         and d.refclassid = 'pg_class'::regclass::oid
         and d.refobjid = r.oid
         and d.refobjsubid = a.attnum
         and d.classid = 'pg_constraint'::regclass::oid
         and d.objid = c.oid
         and c.connamespace = nc.oid
         and c.contype = 'c'::"char"
         and (r.relkind = any (array ['r'::"char", 'p'::"char"]))
         and not a.attisdropped
       union all
       select nr.nspname, r.relname, r.relowner, a.attname, nc.nspname, c.conname
       from pg_namespace nr,
            pg_class r,
            pg_attribute a,
            pg_namespace nc,
            pg_constraint c
       where nr.oid = r.relnamespace
         and r.oid = a.attrelid
         and nc.oid = c.connamespace
         and r.oid = case c.contype when 'f'::"char" then c.confrelid else c.conrelid end
         and (a.attnum = any (case c.contype when 'f'::"char" then c.confkey else c.conkey end))
         and not a.attisdropped
         and (c.contype = any (array ['p'::"char", 'u'::"char", 'f'::"char"]))
         and (r.relkind = any (array ['r'::"char", 'p'::"char"])) ) x(tblschema, tblname, tblowner, colname, cstrschema, cstrname)
where pg_has_role(tblowner, 'USAGE'::text);

alter table constraint_column_usage
    owner to postgres;

grant select on constraint_column_usage to public;

