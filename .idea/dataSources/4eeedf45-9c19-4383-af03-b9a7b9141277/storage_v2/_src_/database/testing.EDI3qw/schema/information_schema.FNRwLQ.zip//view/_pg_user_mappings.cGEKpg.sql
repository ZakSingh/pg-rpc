create view _pg_user_mappings
            (oid, umoptions, umuser, authorization_identifier, foreign_server_catalog, foreign_server_name, srvowner) as
select um.oid,
       um.umoptions,
       um.umuser,
       coalesce(u.rolname, 'PUBLIC'::name)::information_schema.sql_identifier as authorization_identifier,
       s.foreign_server_catalog,
       s.foreign_server_name,
       s.authorization_identifier                                             as srvowner
from pg_user_mapping um
         left join pg_authid u on u.oid = um.umuser,
     information_schema._pg_foreign_servers s
where s.oid = um.umserver;

alter table _pg_user_mappings
    owner to postgres;

