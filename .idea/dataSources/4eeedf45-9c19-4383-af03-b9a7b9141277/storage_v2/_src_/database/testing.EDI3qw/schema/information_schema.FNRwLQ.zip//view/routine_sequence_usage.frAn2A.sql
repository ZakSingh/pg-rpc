create view routine_sequence_usage
            (specific_catalog, specific_schema, specific_name, routine_catalog, routine_schema, routine_name,
             sequence_catalog, sequence_schema, sequence_name)
as
select distinct current_database()::information_schema.sql_identifier              as specific_catalog,
                np.nspname::information_schema.sql_identifier                      as specific_schema,
                nameconcatoid(p.proname, p.oid)::information_schema.sql_identifier as specific_name,
                current_database()::information_schema.sql_identifier              as routine_catalog,
                np.nspname::information_schema.sql_identifier                      as routine_schema,
                p.proname::information_schema.sql_identifier                       as routine_name,
                current_database()::information_schema.sql_identifier              as sequence_catalog,
                ns.nspname::information_schema.sql_identifier                      as sequence_schema,
                s.relname::information_schema.sql_identifier                       as sequence_name
from pg_namespace np,
     pg_proc p,
     pg_depend d,
     pg_class s,
     pg_namespace ns
where np.oid = p.pronamespace
  and p.oid = d.objid
  and d.classid = 'pg_proc'::regclass::oid
  and d.refobjid = s.oid
  and d.refclassid = 'pg_class'::regclass::oid
  and s.relnamespace = ns.oid
  and s.relkind = 'S'::"char"
  and pg_has_role(s.relowner, 'USAGE'::text);

alter table routine_sequence_usage
    owner to postgres;

grant select on routine_sequence_usage to public;

