create view pg_statio_user_indexes
            (relid, indexrelid, schemaname, relname, indexrelname, idx_blks_read, idx_blks_hit) as
select relid, indexrelid, schemaname, relname, indexrelname, idx_blks_read, idx_blks_hit
from pg_statio_all_indexes
where (schemaname <> all (array ['pg_catalog'::name, 'information_schema'::name]))
  and schemaname !~ '^pg_toast'::text;

alter table pg_statio_user_indexes
    owner to postgres;

grant select on pg_statio_user_indexes to public;

