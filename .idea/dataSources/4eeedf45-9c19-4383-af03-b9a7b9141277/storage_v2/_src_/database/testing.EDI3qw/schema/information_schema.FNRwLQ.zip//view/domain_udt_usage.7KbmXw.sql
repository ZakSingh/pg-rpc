create view domain_udt_usage (udt_catalog, udt_schema, udt_name, domain_catalog, domain_schema, domain_name) as
select current_database()::information_schema.sql_identifier as udt_catalog,
       nbt.nspname::information_schema.sql_identifier        as udt_schema,
       bt.typname::information_schema.sql_identifier         as udt_name,
       current_database()::information_schema.sql_identifier as domain_catalog,
       nt.nspname::information_schema.sql_identifier         as domain_schema,
       t.typname::information_schema.sql_identifier          as domain_name
from pg_type t,
     pg_namespace nt,
     pg_type bt,
     pg_namespace nbt
where t.typnamespace = nt.oid
  and t.typbasetype = bt.oid
  and bt.typnamespace = nbt.oid
  and t.typtype = 'd'::"char"
  and pg_has_role(bt.typowner, 'USAGE'::text);

alter table domain_udt_usage
    owner to postgres;

grant select on domain_udt_usage to public;

