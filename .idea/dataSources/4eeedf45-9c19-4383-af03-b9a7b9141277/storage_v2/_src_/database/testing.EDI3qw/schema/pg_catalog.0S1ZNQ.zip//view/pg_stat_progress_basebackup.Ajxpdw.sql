create view pg_stat_progress_basebackup
            (pid, phase, backup_total, backup_streamed, tablespaces_total, tablespaces_streamed) as
select pid,
       case param1 when 0 then 'initializing'::text
                   when 1 then 'waiting for checkpoint to finish'::text
                   when 2 then 'estimating backup size'::text
                   when 3 then 'streaming database files'::text
                   when 4 then 'waiting for wal archiving to finish'::text
                   when 5 then 'transferring wal files'::text
                   else null::text end                                  as phase,
       case param2 when '-1'::integer then null::bigint else param2 end as backup_total,
       param3                                                           as backup_streamed,
       param4                                                           as tablespaces_total,
       param5                                                           as tablespaces_streamed
from pg_stat_get_progress_info('BASEBACKUP'::text) s(pid, datid, relid, param1, param2, param3, param4, param5, param6,
                                                     param7, param8, param9, param10, param11, param12, param13,
                                                     param14, param15, param16, param17, param18, param19, param20);

alter table pg_stat_progress_basebackup
    owner to postgres;

grant select on pg_stat_progress_basebackup to public;

