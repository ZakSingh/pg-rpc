create function create_account(name text, age integer, role role) returns account
    language plpgsql as
$$
declare
    result account;
begin
    insert into account (name, age, role)
    values (name, age, role)
    returning * into result;

    return result;
end;
$$;

alter function create_account(text, integer, role) owner to postgres;

