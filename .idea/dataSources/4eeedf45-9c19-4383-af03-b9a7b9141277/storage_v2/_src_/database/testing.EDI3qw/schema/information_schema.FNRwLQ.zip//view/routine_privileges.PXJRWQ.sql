create view routine_privileges
            (grantor, grantee, specific_catalog, specific_schema, specific_name, routine_catalog, routine_schema,
             routine_name, privilege_type, is_grantable)
as
select u_grantor.rolname::information_schema.sql_identifier               as grantor,
       grantee.rolname::information_schema.sql_identifier                 as grantee,
       current_database()::information_schema.sql_identifier              as specific_catalog,
       n.nspname::information_schema.sql_identifier                       as specific_schema,
       nameconcatoid(p.proname, p.oid)::information_schema.sql_identifier as specific_name,
       current_database()::information_schema.sql_identifier              as routine_catalog,
       n.nspname::information_schema.sql_identifier                       as routine_schema,
       p.proname::information_schema.sql_identifier                       as routine_name,
       'EXECUTE'::character varying::information_schema.character_data    as privilege_type,
       case when pg_has_role(grantee.oid, p.proowner, 'USAGE'::text) or p.grantable then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no             as is_grantable
from ( select pg_proc.oid,
              pg_proc.proname,
              pg_proc.proowner,
              pg_proc.pronamespace,
              (aclexplode(coalesce(pg_proc.proacl, acldefault('f'::"char", pg_proc.proowner)))).grantor        as grantor,
              (aclexplode(coalesce(pg_proc.proacl,
                                   acldefault('f'::"char", pg_proc.proowner)))).grantee                        as grantee,
              (aclexplode(coalesce(pg_proc.proacl,
                                   acldefault('f'::"char", pg_proc.proowner)))).privilege_type                 as privilege_type,
              (aclexplode(coalesce(pg_proc.proacl,
                                   acldefault('f'::"char", pg_proc.proowner)))).is_grantable                   as is_grantable
       from pg_proc ) p(oid, proname, proowner, pronamespace, grantor, grantee, prtype, grantable),
     pg_namespace n,
     pg_authid u_grantor,
     ( select pg_authid.oid, pg_authid.rolname
       from pg_authid
       union all
       select 0::oid as oid, 'PUBLIC'::name ) grantee(oid, rolname)
where p.pronamespace = n.oid
  and grantee.oid = p.grantee
  and u_grantor.oid = p.grantor
  and p.prtype = 'EXECUTE'::text
  and (pg_has_role(u_grantor.oid, 'USAGE'::text) or pg_has_role(grantee.oid, 'USAGE'::text) or
       grantee.rolname = 'PUBLIC'::name);

alter table routine_privileges
    owner to postgres;

grant select on routine_privileges to public;

