create view pg_statio_user_tables
            (relid, schemaname, relname, heap_blks_read, heap_blks_hit, idx_blks_read, idx_blks_hit, toast_blks_read,
             toast_blks_hit, tidx_blks_read, tidx_blks_hit)
as
select relid,
       schemaname,
       relname,
       heap_blks_read,
       heap_blks_hit,
       idx_blks_read,
       idx_blks_hit,
       toast_blks_read,
       toast_blks_hit,
       tidx_blks_read,
       tidx_blks_hit
from pg_statio_all_tables
where (schemaname <> all (array ['pg_catalog'::name, 'information_schema'::name]))
  and schemaname !~ '^pg_toast'::text;

alter table pg_statio_user_tables
    owner to postgres;

grant select on pg_statio_user_tables to public;

