create view pg_stats_ext_exprs
            (schemaname, tablename, statistics_schemaname, statistics_name, statistics_owner, expr, inherited,
             null_frac, avg_width, n_distinct, most_common_vals, most_common_freqs, histogram_bounds, correlation,
             most_common_elems, most_common_elem_freqs, elem_count_histogram)
as
select cn.nspname                   as schemaname,
       c.relname                    as tablename,
       sn.nspname                   as statistics_schemaname,
       s.stxname                    as statistics_name,
       pg_get_userbyid(s.stxowner)  as statistics_owner,
       stat.expr,
       sd.stxdinherit               as inherited,
       (stat.a).stanullfrac         as null_frac,
       (stat.a).stawidth            as avg_width,
       (stat.a).stadistinct         as n_distinct,
       case when (stat.a).stakind1 = 1 then (stat.a).stavalues1
            when (stat.a).stakind2 = 1 then (stat.a).stavalues2
            when (stat.a).stakind3 = 1 then (stat.a).stavalues3
            when (stat.a).stakind4 = 1 then (stat.a).stavalues4
            when (stat.a).stakind5 = 1 then (stat.a).stavalues5
            else null::anyarray end as most_common_vals,
       case when (stat.a).stakind1 = 1 then (stat.a).stanumbers1
            when (stat.a).stakind2 = 1 then (stat.a).stanumbers2
            when (stat.a).stakind3 = 1 then (stat.a).stanumbers3
            when (stat.a).stakind4 = 1 then (stat.a).stanumbers4
            when (stat.a).stakind5 = 1 then (stat.a).stanumbers5
            else null::real[] end   as most_common_freqs,
       case when (stat.a).stakind1 = 2 then (stat.a).stavalues1
            when (stat.a).stakind2 = 2 then (stat.a).stavalues2
            when (stat.a).stakind3 = 2 then (stat.a).stavalues3
            when (stat.a).stakind4 = 2 then (stat.a).stavalues4
            when (stat.a).stakind5 = 2 then (stat.a).stavalues5
            else null::anyarray end as histogram_bounds,
       case when (stat.a).stakind1 = 3 then (stat.a).stanumbers1[1]
            when (stat.a).stakind2 = 3 then (stat.a).stanumbers2[1]
            when (stat.a).stakind3 = 3 then (stat.a).stanumbers3[1]
            when (stat.a).stakind4 = 3 then (stat.a).stanumbers4[1]
            when (stat.a).stakind5 = 3 then (stat.a).stanumbers5[1]
            else null::real end     as correlation,
       case when (stat.a).stakind1 = 4 then (stat.a).stavalues1
            when (stat.a).stakind2 = 4 then (stat.a).stavalues2
            when (stat.a).stakind3 = 4 then (stat.a).stavalues3
            when (stat.a).stakind4 = 4 then (stat.a).stavalues4
            when (stat.a).stakind5 = 4 then (stat.a).stavalues5
            else null::anyarray end as most_common_elems,
       case when (stat.a).stakind1 = 4 then (stat.a).stanumbers1
            when (stat.a).stakind2 = 4 then (stat.a).stanumbers2
            when (stat.a).stakind3 = 4 then (stat.a).stanumbers3
            when (stat.a).stakind4 = 4 then (stat.a).stanumbers4
            when (stat.a).stakind5 = 4 then (stat.a).stanumbers5
            else null::real[] end   as most_common_elem_freqs,
       case when (stat.a).stakind1 = 5 then (stat.a).stanumbers1
            when (stat.a).stakind2 = 5 then (stat.a).stanumbers2
            when (stat.a).stakind3 = 5 then (stat.a).stanumbers3
            when (stat.a).stakind4 = 5 then (stat.a).stanumbers4
            when (stat.a).stakind5 = 5 then (stat.a).stanumbers5
            else null::real[] end   as elem_count_histogram
from pg_statistic_ext s
         join pg_class c on c.oid = s.stxrelid
         left join pg_statistic_ext_data sd on s.oid = sd.stxoid
         left join pg_namespace cn on cn.oid = c.relnamespace
         left join pg_namespace sn on sn.oid = s.stxnamespace
         join lateral ( select unnest(pg_get_statisticsobjdef_expressions(s.oid)) as expr,
                               unnest(sd.stxdexpr)                                as a) stat on stat.expr is not null
where pg_has_role(c.relowner, 'USAGE'::text)
  and (c.relrowsecurity = false or not row_security_active(c.oid));

alter table pg_stats_ext_exprs
    owner to postgres;

grant select on pg_stats_ext_exprs to public;

