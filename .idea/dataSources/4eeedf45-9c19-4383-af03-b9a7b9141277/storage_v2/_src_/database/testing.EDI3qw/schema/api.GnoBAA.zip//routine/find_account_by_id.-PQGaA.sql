create function find_account_by_id(p_account_id integer) returns SETOF account
    language plpgsql as
$$
begin
    return query select * from account
                 where account_id = p_account_id;
end;
$$;

alter function find_account_by_id(integer) owner to postgres;

