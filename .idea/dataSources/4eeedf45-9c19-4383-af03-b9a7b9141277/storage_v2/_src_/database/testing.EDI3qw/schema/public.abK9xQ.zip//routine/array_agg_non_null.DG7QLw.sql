create function array_agg_non_null(input_set anyelement) returns anyarray
    immutable
    language sql as
$$
select coalesce(array_agg(value), '{}')
from (select input_set as value) as subquery
where value is not null;
$$;

alter function array_agg_non_null(anyelement) owner to postgres;

