create function always_returns_value() returns integer
    language sql as
$$
SELECT 1;
$$;

alter function always_returns_value() owner to postgres;

