create view pg_available_extensions(name, default_version, installed_version, comment) as
select e.name, e.default_version, x.extversion as installed_version, e.comment
from pg_available_extensions() e(name, default_version, comment)
         left join pg_extension x on e.name = x.extname;

alter table pg_available_extensions
    owner to postgres;

grant select on pg_available_extensions to public;

