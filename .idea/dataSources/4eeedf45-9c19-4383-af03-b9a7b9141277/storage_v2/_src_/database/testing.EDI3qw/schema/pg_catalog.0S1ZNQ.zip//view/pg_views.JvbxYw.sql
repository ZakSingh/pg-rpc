create view pg_views(schemaname, viewname, viewowner, definition) as
select n.nspname                   as schemaname,
       c.relname                   as viewname,
       pg_get_userbyid(c.relowner) as viewowner,
       pg_get_viewdef(c.oid)       as definition
from pg_class c
         left join pg_namespace n on n.oid = c.relnamespace
where c.relkind = 'v'::"char";

alter table pg_views
    owner to postgres;

grant select on pg_views to public;

