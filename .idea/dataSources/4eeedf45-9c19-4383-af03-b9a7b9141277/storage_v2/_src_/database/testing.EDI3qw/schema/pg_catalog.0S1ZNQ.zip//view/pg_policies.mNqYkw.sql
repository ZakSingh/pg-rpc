create view pg_policies (schemaname, tablename, policyname, permissive, roles, cmd, qual, with_check) as
select n.nspname                                                                        as schemaname,
       c.relname                                                                        as tablename,
       pol.polname                                                                      as policyname,
       case when pol.polpermissive then 'PERMISSIVE'::text else 'RESTRICTIVE'::text end as permissive,
       case when pol.polroles = '{0}'::oid[] then string_to_array('public'::text, ''::text)::name[]
            else array(select pg_authid.rolname
                       from pg_authid
                       where pg_authid.oid = any (pol.polroles)
                       order by pg_authid.rolname) end                                  as roles,
       case pol.polcmd when 'r'::"char" then 'SELECT'::text
                       when 'a'::"char" then 'INSERT'::text
                       when 'w'::"char" then 'UPDATE'::text
                       when 'd'::"char" then 'DELETE'::text
                       when '*'::"char" then 'ALL'::text
                       else null::text end                                              as cmd,
       pg_get_expr(pol.polqual, pol.polrelid)                                           as qual,
       pg_get_expr(pol.polwithcheck, pol.polrelid)                                      as with_check
from pg_policy pol
         join pg_class c on c.oid = pol.polrelid
         left join pg_namespace n on n.oid = c.relnamespace;

alter table pg_policies
    owner to postgres;

grant select on pg_policies to public;

