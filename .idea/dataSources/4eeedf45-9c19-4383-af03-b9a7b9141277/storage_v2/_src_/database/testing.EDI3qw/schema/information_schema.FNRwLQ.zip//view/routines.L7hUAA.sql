create view routines
            (specific_catalog, specific_schema, specific_name, routine_catalog, routine_schema, routine_name,
             routine_type, module_catalog, module_schema, module_name, udt_catalog, udt_schema, udt_name, data_type,
             character_maximum_length, character_octet_length, character_set_catalog, character_set_schema,
             character_set_name, collation_catalog, collation_schema, collation_name, numeric_precision,
             numeric_precision_radix, numeric_scale, datetime_precision, interval_type, interval_precision,
             type_udt_catalog, type_udt_schema, type_udt_name, scope_catalog, scope_schema, scope_name,
             maximum_cardinality, dtd_identifier, routine_body, routine_definition, external_name, external_language,
             parameter_style, is_deterministic, sql_data_access, is_null_call, sql_path, schema_level_routine,
             max_dynamic_result_sets, is_user_defined_cast, is_implicitly_invocable, security_type,
             to_sql_specific_catalog, to_sql_specific_schema, to_sql_specific_name, as_locator, created, last_altered,
             new_savepoint_level, is_udt_dependent, result_cast_from_data_type, result_cast_as_locator,
             result_cast_char_max_length, result_cast_char_octet_length, result_cast_char_set_catalog,
             result_cast_char_set_schema, result_cast_char_set_name, result_cast_collation_catalog,
             result_cast_collation_schema, result_cast_collation_name, result_cast_numeric_precision,
             result_cast_numeric_precision_radix, result_cast_numeric_scale, result_cast_datetime_precision,
             result_cast_interval_type, result_cast_interval_precision, result_cast_type_udt_catalog,
             result_cast_type_udt_schema, result_cast_type_udt_name, result_cast_scope_catalog,
             result_cast_scope_schema, result_cast_scope_name, result_cast_maximum_cardinality,
             result_cast_dtd_identifier)
as
select current_database()::information_schema.sql_identifier                                                    as specific_catalog,
       n.nspname::information_schema.sql_identifier                                                             as specific_schema,
       nameconcatoid(p.proname, p.oid)::information_schema.sql_identifier                                       as specific_name,
       current_database()::information_schema.sql_identifier                                                    as routine_catalog,
       n.nspname::information_schema.sql_identifier                                                             as routine_schema,
       p.proname::information_schema.sql_identifier                                                             as routine_name,
       case p.prokind when 'f'::"char" then 'FUNCTION'::text
                      when 'p'::"char" then 'PROCEDURE'::text
                      else null::text end::information_schema.character_data                                    as routine_type,
       null::name::information_schema.sql_identifier                                                            as module_catalog,
       null::name::information_schema.sql_identifier                                                            as module_schema,
       null::name::information_schema.sql_identifier                                                            as module_name,
       null::name::information_schema.sql_identifier                                                            as udt_catalog,
       null::name::information_schema.sql_identifier                                                            as udt_schema,
       null::name::information_schema.sql_identifier                                                            as udt_name,
       case when p.prokind = 'p'::"char" then null::text
            when t.typelem <> 0::oid and t.typlen = '-1'::integer then 'ARRAY'::text
            when nt.nspname = 'pg_catalog'::name then format_type(t.oid, null::integer)
            else 'USER-DEFINED'::text end::information_schema.character_data                                    as data_type,
       null::integer::information_schema.cardinal_number                                                        as character_maximum_length,
       null::integer::information_schema.cardinal_number                                                        as character_octet_length,
       null::name::information_schema.sql_identifier                                                            as character_set_catalog,
       null::name::information_schema.sql_identifier                                                            as character_set_schema,
       null::name::information_schema.sql_identifier                                                            as character_set_name,
       null::name::information_schema.sql_identifier                                                            as collation_catalog,
       null::name::information_schema.sql_identifier                                                            as collation_schema,
       null::name::information_schema.sql_identifier                                                            as collation_name,
       null::integer::information_schema.cardinal_number                                                        as numeric_precision,
       null::integer::information_schema.cardinal_number                                                        as numeric_precision_radix,
       null::integer::information_schema.cardinal_number                                                        as numeric_scale,
       null::integer::information_schema.cardinal_number                                                        as datetime_precision,
       null::character varying::information_schema.character_data                                               as interval_type,
       null::integer::information_schema.cardinal_number                                                        as interval_precision,
       case when nt.nspname is not null then current_database()
            else null::name end::information_schema.sql_identifier                                              as type_udt_catalog,
       nt.nspname::information_schema.sql_identifier                                                            as type_udt_schema,
       t.typname::information_schema.sql_identifier                                                             as type_udt_name,
       null::name::information_schema.sql_identifier                                                            as scope_catalog,
       null::name::information_schema.sql_identifier                                                            as scope_schema,
       null::name::information_schema.sql_identifier                                                            as scope_name,
       null::integer::information_schema.cardinal_number                                                        as maximum_cardinality,
       case when p.prokind <> 'p'::"char" then 0 else null::integer end::information_schema.sql_identifier      as dtd_identifier,
       case when l.lanname = 'sql'::name then 'SQL'::text
            else 'EXTERNAL'::text end::information_schema.character_data                                        as routine_body,
       case when pg_has_role(p.proowner, 'USAGE'::text) then p.prosrc
            else null::text end::information_schema.character_data                                              as routine_definition,
       case when l.lanname = 'c'::name then p.prosrc else null::text end::information_schema.character_data     as external_name,
       upper(l.lanname::text)::information_schema.character_data                                                as external_language,
       'GENERAL'::character varying::information_schema.character_data                                          as parameter_style,
       case when p.provolatile = 'i'::"char" then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no                                                   as is_deterministic,
       'MODIFIES'::character varying::information_schema.character_data                                         as sql_data_access,
       case when p.prokind <> 'p'::"char" then case when p.proisstrict then 'YES'::text else 'NO'::text end
            else null::text end::information_schema.yes_or_no                                                   as is_null_call,
       null::character varying::information_schema.character_data                                               as sql_path,
       'YES'::character varying::information_schema.yes_or_no                                                   as schema_level_routine,
       0::information_schema.cardinal_number                                                                    as max_dynamic_result_sets,
       null::character varying::information_schema.yes_or_no                                                    as is_user_defined_cast,
       null::character varying::information_schema.yes_or_no                                                    as is_implicitly_invocable,
       case when p.prosecdef then 'DEFINER'::text else 'INVOKER'::text end::information_schema.character_data   as security_type,
       null::name::information_schema.sql_identifier                                                            as to_sql_specific_catalog,
       null::name::information_schema.sql_identifier                                                            as to_sql_specific_schema,
       null::name::information_schema.sql_identifier                                                            as to_sql_specific_name,
       'NO'::character varying::information_schema.yes_or_no                                                    as as_locator,
       null::timestamp with time zone::information_schema.time_stamp                                            as created,
       null::timestamp with time zone::information_schema.time_stamp                                            as last_altered,
       null::character varying::information_schema.yes_or_no                                                    as new_savepoint_level,
       'NO'::character varying::information_schema.yes_or_no                                                    as is_udt_dependent,
       null::character varying::information_schema.character_data                                               as result_cast_from_data_type,
       null::character varying::information_schema.yes_or_no                                                    as result_cast_as_locator,
       null::integer::information_schema.cardinal_number                                                        as result_cast_char_max_length,
       null::integer::information_schema.cardinal_number                                                        as result_cast_char_octet_length,
       null::name::information_schema.sql_identifier                                                            as result_cast_char_set_catalog,
       null::name::information_schema.sql_identifier                                                            as result_cast_char_set_schema,
       null::name::information_schema.sql_identifier                                                            as result_cast_char_set_name,
       null::name::information_schema.sql_identifier                                                            as result_cast_collation_catalog,
       null::name::information_schema.sql_identifier                                                            as result_cast_collation_schema,
       null::name::information_schema.sql_identifier                                                            as result_cast_collation_name,
       null::integer::information_schema.cardinal_number                                                        as result_cast_numeric_precision,
       null::integer::information_schema.cardinal_number                                                        as result_cast_numeric_precision_radix,
       null::integer::information_schema.cardinal_number                                                        as result_cast_numeric_scale,
       null::integer::information_schema.cardinal_number                                                        as result_cast_datetime_precision,
       null::character varying::information_schema.character_data                                               as result_cast_interval_type,
       null::integer::information_schema.cardinal_number                                                        as result_cast_interval_precision,
       null::name::information_schema.sql_identifier                                                            as result_cast_type_udt_catalog,
       null::name::information_schema.sql_identifier                                                            as result_cast_type_udt_schema,
       null::name::information_schema.sql_identifier                                                            as result_cast_type_udt_name,
       null::name::information_schema.sql_identifier                                                            as result_cast_scope_catalog,
       null::name::information_schema.sql_identifier                                                            as result_cast_scope_schema,
       null::name::information_schema.sql_identifier                                                            as result_cast_scope_name,
       null::integer::information_schema.cardinal_number                                                        as result_cast_maximum_cardinality,
       null::name::information_schema.sql_identifier                                                            as result_cast_dtd_identifier
from pg_namespace n
         join pg_proc p on n.oid = p.pronamespace
         join pg_language l on p.prolang = l.oid
         left join ( pg_type t join pg_namespace nt on t.typnamespace = nt.oid )
                   on p.prorettype = t.oid and p.prokind <> 'p'::"char"
where pg_has_role(p.proowner, 'USAGE'::text)
   or has_function_privilege(p.oid, 'EXECUTE'::text);

alter table routines
    owner to postgres;

grant select on routines to public;

