create view collations(collation_catalog, collation_schema, collation_name, pad_attribute) as
select current_database()::information_schema.sql_identifier          as collation_catalog,
       nc.nspname::information_schema.sql_identifier                  as collation_schema,
       c.collname::information_schema.sql_identifier                  as collation_name,
       'NO PAD'::character varying::information_schema.character_data as pad_attribute
from pg_collation c,
     pg_namespace nc
where c.collnamespace = nc.oid
  and (c.collencoding = any (array ['-1'::integer, ( select pg_database.encoding
                                                     from pg_database
                                                     where pg_database.datname = current_database() )]));

alter table collations
    owner to postgres;

grant select on collations to public;

