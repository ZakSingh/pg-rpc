create view usage_privileges
            (grantor, grantee, object_catalog, object_schema, object_name, object_type, privilege_type, is_grantable) as
select u.rolname::information_schema.sql_identifier                      as grantor,
       'PUBLIC'::name::information_schema.sql_identifier                 as grantee,
       current_database()::information_schema.sql_identifier             as object_catalog,
       n.nspname::information_schema.sql_identifier                      as object_schema,
       c.collname::information_schema.sql_identifier                     as object_name,
       'COLLATION'::character varying::information_schema.character_data as object_type,
       'USAGE'::character varying::information_schema.character_data     as privilege_type,
       'NO'::character varying::information_schema.yes_or_no             as is_grantable
from pg_authid u,
     pg_namespace n,
     pg_collation c
where u.oid = c.collowner
  and c.collnamespace = n.oid
  and (c.collencoding = any (array ['-1'::integer, ( select pg_database.encoding
                                                     from pg_database
                                                     where pg_database.datname = current_database() )]))
union all
select u_grantor.rolname::information_schema.sql_identifier           as grantor,
       grantee.rolname::information_schema.sql_identifier             as grantee,
       current_database()::information_schema.sql_identifier          as object_catalog,
       n.nspname::information_schema.sql_identifier                   as object_schema,
       t.typname::information_schema.sql_identifier                   as object_name,
       'DOMAIN'::character varying::information_schema.character_data as object_type,
       'USAGE'::character varying::information_schema.character_data  as privilege_type,
       case when pg_has_role(grantee.oid, t.typowner, 'USAGE'::text) or t.grantable then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no         as is_grantable
from ( select pg_type.oid,
              pg_type.typname,
              pg_type.typnamespace,
              pg_type.typtype,
              pg_type.typowner,
              (aclexplode(coalesce(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).grantor        as grantor,
              (aclexplode(coalesce(pg_type.typacl,
                                   acldefault('T'::"char", pg_type.typowner)))).grantee                        as grantee,
              (aclexplode(coalesce(pg_type.typacl,
                                   acldefault('T'::"char", pg_type.typowner)))).privilege_type                 as privilege_type,
              (aclexplode(coalesce(pg_type.typacl,
                                   acldefault('T'::"char", pg_type.typowner)))).is_grantable                   as is_grantable
       from pg_type ) t(oid, typname, typnamespace, typtype, typowner, grantor, grantee, prtype, grantable),
     pg_namespace n,
     pg_authid u_grantor,
     ( select pg_authid.oid, pg_authid.rolname
       from pg_authid
       union all
       select 0::oid as oid, 'PUBLIC'::name ) grantee(oid, rolname)
where t.typnamespace = n.oid
  and t.typtype = 'd'::"char"
  and t.grantee = grantee.oid
  and t.grantor = u_grantor.oid
  and t.prtype = 'USAGE'::text
  and (pg_has_role(u_grantor.oid, 'USAGE'::text) or pg_has_role(grantee.oid, 'USAGE'::text) or
       grantee.rolname = 'PUBLIC'::name)
union all
select u_grantor.rolname::information_schema.sql_identifier                         as grantor,
       grantee.rolname::information_schema.sql_identifier                           as grantee,
       current_database()::information_schema.sql_identifier                        as object_catalog,
       ''::name::information_schema.sql_identifier                                  as object_schema,
       fdw.fdwname::information_schema.sql_identifier                               as object_name,
       'FOREIGN DATA WRAPPER'::character varying::information_schema.character_data as object_type,
       'USAGE'::character varying::information_schema.character_data                as privilege_type,
       case when pg_has_role(grantee.oid, fdw.fdwowner, 'USAGE'::text) or fdw.grantable then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no                       as is_grantable
from ( select pg_foreign_data_wrapper.fdwname,
              pg_foreign_data_wrapper.fdwowner,
              (aclexplode(coalesce(pg_foreign_data_wrapper.fdwacl,
                                   acldefault('F'::"char", pg_foreign_data_wrapper.fdwowner)))).grantor        as grantor,
              (aclexplode(coalesce(pg_foreign_data_wrapper.fdwacl,
                                   acldefault('F'::"char", pg_foreign_data_wrapper.fdwowner)))).grantee        as grantee,
              (aclexplode(coalesce(pg_foreign_data_wrapper.fdwacl,
                                   acldefault('F'::"char", pg_foreign_data_wrapper.fdwowner)))).privilege_type as privilege_type,
              (aclexplode(coalesce(pg_foreign_data_wrapper.fdwacl,
                                   acldefault('F'::"char", pg_foreign_data_wrapper.fdwowner)))).is_grantable   as is_grantable
       from pg_foreign_data_wrapper ) fdw(fdwname, fdwowner, grantor, grantee, prtype, grantable),
     pg_authid u_grantor,
     ( select pg_authid.oid, pg_authid.rolname
       from pg_authid
       union all
       select 0::oid as oid, 'PUBLIC'::name ) grantee(oid, rolname)
where u_grantor.oid = fdw.grantor
  and grantee.oid = fdw.grantee
  and fdw.prtype = 'USAGE'::text
  and (pg_has_role(u_grantor.oid, 'USAGE'::text) or pg_has_role(grantee.oid, 'USAGE'::text) or
       grantee.rolname = 'PUBLIC'::name)
union all
select u_grantor.rolname::information_schema.sql_identifier                   as grantor,
       grantee.rolname::information_schema.sql_identifier                     as grantee,
       current_database()::information_schema.sql_identifier                  as object_catalog,
       ''::name::information_schema.sql_identifier                            as object_schema,
       srv.srvname::information_schema.sql_identifier                         as object_name,
       'FOREIGN SERVER'::character varying::information_schema.character_data as object_type,
       'USAGE'::character varying::information_schema.character_data          as privilege_type,
       case when pg_has_role(grantee.oid, srv.srvowner, 'USAGE'::text) or srv.grantable then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no                 as is_grantable
from ( select pg_foreign_server.srvname,
              pg_foreign_server.srvowner,
              (aclexplode(coalesce(pg_foreign_server.srvacl,
                                   acldefault('S'::"char", pg_foreign_server.srvowner)))).grantor        as grantor,
              (aclexplode(coalesce(pg_foreign_server.srvacl,
                                   acldefault('S'::"char", pg_foreign_server.srvowner)))).grantee        as grantee,
              (aclexplode(coalesce(pg_foreign_server.srvacl,
                                   acldefault('S'::"char", pg_foreign_server.srvowner)))).privilege_type as privilege_type,
              (aclexplode(coalesce(pg_foreign_server.srvacl,
                                   acldefault('S'::"char", pg_foreign_server.srvowner)))).is_grantable   as is_grantable
       from pg_foreign_server ) srv(srvname, srvowner, grantor, grantee, prtype, grantable),
     pg_authid u_grantor,
     ( select pg_authid.oid, pg_authid.rolname
       from pg_authid
       union all
       select 0::oid as oid, 'PUBLIC'::name ) grantee(oid, rolname)
where u_grantor.oid = srv.grantor
  and grantee.oid = srv.grantee
  and srv.prtype = 'USAGE'::text
  and (pg_has_role(u_grantor.oid, 'USAGE'::text) or pg_has_role(grantee.oid, 'USAGE'::text) or
       grantee.rolname = 'PUBLIC'::name)
union all
select u_grantor.rolname::information_schema.sql_identifier             as grantor,
       grantee.rolname::information_schema.sql_identifier               as grantee,
       current_database()::information_schema.sql_identifier            as object_catalog,
       n.nspname::information_schema.sql_identifier                     as object_schema,
       c.relname::information_schema.sql_identifier                     as object_name,
       'SEQUENCE'::character varying::information_schema.character_data as object_type,
       'USAGE'::character varying::information_schema.character_data    as privilege_type,
       case when pg_has_role(grantee.oid, c.relowner, 'USAGE'::text) or c.grantable then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no           as is_grantable
from ( select pg_class.oid,
              pg_class.relname,
              pg_class.relnamespace,
              pg_class.relkind,
              pg_class.relowner,
              (aclexplode(coalesce(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).grantor        as grantor,
              (aclexplode(coalesce(pg_class.relacl,
                                   acldefault('r'::"char", pg_class.relowner)))).grantee                         as grantee,
              (aclexplode(coalesce(pg_class.relacl,
                                   acldefault('r'::"char", pg_class.relowner)))).privilege_type                  as privilege_type,
              (aclexplode(coalesce(pg_class.relacl,
                                   acldefault('r'::"char", pg_class.relowner)))).is_grantable                    as is_grantable
       from pg_class ) c(oid, relname, relnamespace, relkind, relowner, grantor, grantee, prtype, grantable),
     pg_namespace n,
     pg_authid u_grantor,
     ( select pg_authid.oid, pg_authid.rolname
       from pg_authid
       union all
       select 0::oid as oid, 'PUBLIC'::name ) grantee(oid, rolname)
where c.relnamespace = n.oid
  and c.relkind = 'S'::"char"
  and c.grantee = grantee.oid
  and c.grantor = u_grantor.oid
  and c.prtype = 'USAGE'::text
  and (pg_has_role(u_grantor.oid, 'USAGE'::text) or pg_has_role(grantee.oid, 'USAGE'::text) or
       grantee.rolname = 'PUBLIC'::name);

alter table usage_privileges
    owner to postgres;

grant select on usage_privileges to public;

