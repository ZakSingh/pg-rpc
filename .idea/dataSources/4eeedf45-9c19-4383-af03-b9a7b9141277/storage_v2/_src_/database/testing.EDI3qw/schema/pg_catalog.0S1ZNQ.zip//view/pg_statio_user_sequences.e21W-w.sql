create view pg_statio_user_sequences(relid, schemaname, relname, blks_read, blks_hit) as
select relid, schemaname, relname, blks_read, blks_hit
from pg_statio_all_sequences
where (schemaname <> all (array ['pg_catalog'::name, 'information_schema'::name]))
  and schemaname !~ '^pg_toast'::text;

alter table pg_statio_user_sequences
    owner to postgres;

grant select on pg_statio_user_sequences to public;

