create view applicable_roles(grantee, role_name, is_grantable) as
select a.rolname::information_schema.sql_identifier                                                as grantee,
       b.rolname::information_schema.sql_identifier                                                as role_name,
       case when m.admin_option then 'YES'::text else 'NO'::text end::information_schema.yes_or_no as is_grantable
from ( select pg_auth_members.member, pg_auth_members.roleid, pg_auth_members.admin_option
       from pg_auth_members
       union
       select pg_database.datdba, pg_authid.oid, false
       from pg_database,
            pg_authid
       where pg_database.datname = current_database()
         and pg_authid.rolname = 'pg_database_owner'::name ) m
         join pg_authid a on m.member = a.oid
         join pg_authid b on m.roleid = b.oid
where pg_has_role(a.oid, 'USAGE'::text);

alter table applicable_roles
    owner to postgres;

grant select on applicable_roles to public;

