create view pg_stat_checkpointer
            (num_timed, num_requested, restartpoints_timed, restartpoints_req, restartpoints_done, write_time,
             sync_time, buffers_written, stats_reset)
as
select pg_stat_get_checkpointer_num_timed()               as num_timed,
       pg_stat_get_checkpointer_num_requested()           as num_requested,
       pg_stat_get_checkpointer_restartpoints_timed()     as restartpoints_timed,
       pg_stat_get_checkpointer_restartpoints_requested() as restartpoints_req,
       pg_stat_get_checkpointer_restartpoints_performed() as restartpoints_done,
       pg_stat_get_checkpointer_write_time()              as write_time,
       pg_stat_get_checkpointer_sync_time()               as sync_time,
       pg_stat_get_checkpointer_buffers_written()         as buffers_written,
       pg_stat_get_checkpointer_stat_reset_time()         as stats_reset;

alter table pg_stat_checkpointer
    owner to postgres;

grant select on pg_stat_checkpointer to public;

