create view table_constraints
            (constraint_catalog, constraint_schema, constraint_name, table_catalog, table_schema, table_name,
             constraint_type, is_deferrable, initially_deferred, enforced, nulls_distinct)
as
select current_database()::information_schema.sql_identifier                                        as constraint_catalog,
       nc.nspname::information_schema.sql_identifier                                                as constraint_schema,
       c.conname::information_schema.sql_identifier                                                 as constraint_name,
       current_database()::information_schema.sql_identifier                                        as table_catalog,
       nr.nspname::information_schema.sql_identifier                                                as table_schema,
       r.relname::information_schema.sql_identifier                                                 as table_name,
       case c.contype when 'c'::"char" then 'CHECK'::text
                      when 'f'::"char" then 'FOREIGN KEY'::text
                      when 'p'::"char" then 'PRIMARY KEY'::text
                      when 'u'::"char" then 'UNIQUE'::text
                      else null::text end::information_schema.character_data                        as constraint_type,
       case when c.condeferrable then 'YES'::text else 'NO'::text end::information_schema.yes_or_no as is_deferrable,
       case when c.condeferred then 'YES'::text else 'NO'::text end::information_schema.yes_or_no   as initially_deferred,
       'YES'::character varying::information_schema.yes_or_no                                       as enforced,
       case when c.contype = 'u'::"char" then case when ( select not pg_index.indnullsnotdistinct
                                                          from pg_index
                                                          where pg_index.indexrelid = c.conindid ) then 'YES'::text
                                                   else 'NO'::text end
            else null::text end::information_schema.yes_or_no                                       as nulls_distinct
from pg_namespace nc,
     pg_namespace nr,
     pg_constraint c,
     pg_class r
where nc.oid = c.connamespace
  and nr.oid = r.relnamespace
  and c.conrelid = r.oid
  and (c.contype <> all (array ['t'::"char", 'x'::"char"]))
  and (r.relkind = any (array ['r'::"char", 'p'::"char"]))
  and not pg_is_other_temp_schema(nr.oid)
  and (pg_has_role(r.relowner, 'USAGE'::text) or
       has_table_privilege(r.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::text) or
       has_any_column_privilege(r.oid, 'INSERT, UPDATE, REFERENCES'::text))
union all
select current_database()::information_schema.sql_identifier         as constraint_catalog,
       nr.nspname::information_schema.sql_identifier                 as constraint_schema,
       (((((nr.oid::text || '_'::text) || r.oid::text) || '_'::text) || a.attnum::text) ||
        '_not_null'::text)::information_schema.sql_identifier        as constraint_name,
       current_database()::information_schema.sql_identifier         as table_catalog,
       nr.nspname::information_schema.sql_identifier                 as table_schema,
       r.relname::information_schema.sql_identifier                  as table_name,
       'CHECK'::character varying::information_schema.character_data as constraint_type,
       'NO'::character varying::information_schema.yes_or_no         as is_deferrable,
       'NO'::character varying::information_schema.yes_or_no         as initially_deferred,
       'YES'::character varying::information_schema.yes_or_no        as enforced,
       null::character varying::information_schema.yes_or_no         as nulls_distinct
from pg_namespace nr,
     pg_class r,
     pg_attribute a
where nr.oid = r.relnamespace
  and r.oid = a.attrelid
  and a.attnotnull
  and a.attnum > 0
  and not a.attisdropped
  and (r.relkind = any (array ['r'::"char", 'p'::"char"]))
  and not pg_is_other_temp_schema(nr.oid)
  and (pg_has_role(r.relowner, 'USAGE'::text) or
       has_table_privilege(r.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::text) or
       has_any_column_privilege(r.oid, 'INSERT, UPDATE, REFERENCES'::text));

alter table table_constraints
    owner to postgres;

grant select on table_constraints to public;

