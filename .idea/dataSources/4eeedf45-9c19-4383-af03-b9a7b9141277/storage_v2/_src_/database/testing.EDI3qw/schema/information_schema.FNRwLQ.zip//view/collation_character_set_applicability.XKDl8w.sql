create view collation_character_set_applicability
            (collation_catalog, collation_schema, collation_name, character_set_catalog, character_set_schema,
             character_set_name) as
select current_database()::information_schema.sql_identifier    as collation_catalog,
       nc.nspname::information_schema.sql_identifier            as collation_schema,
       c.collname::information_schema.sql_identifier            as collation_name,
       null::name::information_schema.sql_identifier            as character_set_catalog,
       null::name::information_schema.sql_identifier            as character_set_schema,
       getdatabaseencoding()::information_schema.sql_identifier as character_set_name
from pg_collation c,
     pg_namespace nc
where c.collnamespace = nc.oid
  and (c.collencoding = any (array ['-1'::integer, ( select pg_database.encoding
                                                     from pg_database
                                                     where pg_database.datname = current_database() )]));

alter table collation_character_set_applicability
    owner to postgres;

grant select on collation_character_set_applicability to public;

