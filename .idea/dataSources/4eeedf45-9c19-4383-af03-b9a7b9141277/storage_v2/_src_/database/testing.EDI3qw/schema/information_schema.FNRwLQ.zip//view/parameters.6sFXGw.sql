create view parameters
            (specific_catalog, specific_schema, specific_name, ordinal_position, parameter_mode, is_result, as_locator,
             parameter_name, data_type, character_maximum_length, character_octet_length, character_set_catalog,
             character_set_schema, character_set_name, collation_catalog, collation_schema, collation_name,
             numeric_precision, numeric_precision_radix, numeric_scale, datetime_precision, interval_type,
             interval_precision, udt_catalog, udt_schema, udt_name, scope_catalog, scope_schema, scope_name,
             maximum_cardinality, dtd_identifier, parameter_default)
as
select current_database()::information_schema.sql_identifier                         as specific_catalog,
       ss.n_nspname::information_schema.sql_identifier                               as specific_schema,
       nameconcatoid(ss.proname, ss.p_oid)::information_schema.sql_identifier        as specific_name,
       (ss.x).n::information_schema.cardinal_number                                  as ordinal_position,
       case when ss.proargmodes is null then 'IN'::text
            when ss.proargmodes[(ss.x).n] = 'i'::"char" then 'IN'::text
            when ss.proargmodes[(ss.x).n] = 'o'::"char" then 'OUT'::text
            when ss.proargmodes[(ss.x).n] = 'b'::"char" then 'INOUT'::text
            when ss.proargmodes[(ss.x).n] = 'v'::"char" then 'IN'::text
            when ss.proargmodes[(ss.x).n] = 't'::"char" then 'OUT'::text
            else null::text end::information_schema.character_data                   as parameter_mode,
       'NO'::character varying::information_schema.yes_or_no                         as is_result,
       'NO'::character varying::information_schema.yes_or_no                         as as_locator,
       nullif(ss.proargnames[(ss.x).n], ''::text)::information_schema.sql_identifier as parameter_name,
       case when t.typelem <> 0::oid and t.typlen = '-1'::integer then 'ARRAY'::text
            when nt.nspname = 'pg_catalog'::name then format_type(t.oid, null::integer)
            else 'USER-DEFINED'::text end::information_schema.character_data         as data_type,
       null::integer::information_schema.cardinal_number                             as character_maximum_length,
       null::integer::information_schema.cardinal_number                             as character_octet_length,
       null::name::information_schema.sql_identifier                                 as character_set_catalog,
       null::name::information_schema.sql_identifier                                 as character_set_schema,
       null::name::information_schema.sql_identifier                                 as character_set_name,
       null::name::information_schema.sql_identifier                                 as collation_catalog,
       null::name::information_schema.sql_identifier                                 as collation_schema,
       null::name::information_schema.sql_identifier                                 as collation_name,
       null::integer::information_schema.cardinal_number                             as numeric_precision,
       null::integer::information_schema.cardinal_number                             as numeric_precision_radix,
       null::integer::information_schema.cardinal_number                             as numeric_scale,
       null::integer::information_schema.cardinal_number                             as datetime_precision,
       null::character varying::information_schema.character_data                    as interval_type,
       null::integer::information_schema.cardinal_number                             as interval_precision,
       current_database()::information_schema.sql_identifier                         as udt_catalog,
       nt.nspname::information_schema.sql_identifier                                 as udt_schema,
       t.typname::information_schema.sql_identifier                                  as udt_name,
       null::name::information_schema.sql_identifier                                 as scope_catalog,
       null::name::information_schema.sql_identifier                                 as scope_schema,
       null::name::information_schema.sql_identifier                                 as scope_name,
       null::integer::information_schema.cardinal_number                             as maximum_cardinality,
       (ss.x).n::information_schema.sql_identifier                                   as dtd_identifier,
       case when pg_has_role(ss.proowner, 'USAGE'::text) then pg_get_function_arg_default(ss.p_oid, (ss.x).n)
            else null::text end::information_schema.character_data                   as parameter_default
from pg_type t,
     pg_namespace nt,
     ( select n.nspname                                                                            as n_nspname,
              p.proname,
              p.oid                                                                                as p_oid,
              p.proowner,
              p.proargnames,
              p.proargmodes,
              information_schema._pg_expandarray(coalesce(p.proallargtypes, p.proargtypes::oid[])) as x
       from pg_namespace n,
            pg_proc p
       where n.oid = p.pronamespace
         and (pg_has_role(p.proowner, 'USAGE'::text) or has_function_privilege(p.oid, 'EXECUTE'::text)) ) ss
where t.oid = (ss.x).x
  and t.typnamespace = nt.oid;

alter table parameters
    owner to postgres;

grant select on parameters to public;

