create view administrable_role_authorizations(grantee, role_name, is_grantable) as
select grantee, role_name, is_grantable
from information_schema.applicable_roles
where is_grantable::text = 'YES'::text;

alter table administrable_role_authorizations
    owner to postgres;

grant select on administrable_role_authorizations to public;

