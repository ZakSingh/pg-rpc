create view role_column_grants
            (grantor, grantee, table_catalog, table_schema, table_name, column_name, privilege_type, is_grantable) as
select grantor,
       grantee,
       table_catalog,
       table_schema,
       table_name,
       column_name,
       privilege_type,
       is_grantable
from information_schema.column_privileges
where (grantor::name in ( select enabled_roles.role_name from information_schema.enabled_roles ))
   or (grantee::name in ( select enabled_roles.role_name from information_schema.enabled_roles ));

alter table role_column_grants
    owner to postgres;

grant select on role_column_grants to public;

