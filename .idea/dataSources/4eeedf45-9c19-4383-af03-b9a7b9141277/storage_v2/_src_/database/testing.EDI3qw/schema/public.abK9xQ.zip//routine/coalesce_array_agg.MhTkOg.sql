create function coalesce_array_agg(value anyelement) returns anyarray
    immutable parallel safe
    language sql as
$$
select coalesce(array_agg($1) FILTER (WHERE $1 IS NOT NULL), '{}');
$$;

alter function coalesce_array_agg(anyelement) owner to postgres;

