create view element_types
            (object_catalog, object_schema, object_name, object_type, collection_type_identifier, data_type,
             character_maximum_length, character_octet_length, character_set_catalog, character_set_schema,
             character_set_name, collation_catalog, collation_schema, collation_name, numeric_precision,
             numeric_precision_radix, numeric_scale, datetime_precision, interval_type, interval_precision, udt_catalog,
             udt_schema, udt_name, scope_catalog, scope_schema, scope_name, maximum_cardinality, dtd_identifier)
as
select current_database()::information_schema.sql_identifier                 as object_catalog,
       n.nspname::information_schema.sql_identifier                          as object_schema,
       x.objname                                                             as object_name,
       x.objtype::information_schema.character_data                          as object_type,
       x.objdtdid::information_schema.sql_identifier                         as collection_type_identifier,
       case when nbt.nspname = 'pg_catalog'::name then format_type(bt.oid, null::integer)
            else 'USER-DEFINED'::text end::information_schema.character_data as data_type,
       null::integer::information_schema.cardinal_number                     as character_maximum_length,
       null::integer::information_schema.cardinal_number                     as character_octet_length,
       null::name::information_schema.sql_identifier                         as character_set_catalog,
       null::name::information_schema.sql_identifier                         as character_set_schema,
       null::name::information_schema.sql_identifier                         as character_set_name,
       case when nco.nspname is not null then current_database()
            else null::name end::information_schema.sql_identifier           as collation_catalog,
       nco.nspname::information_schema.sql_identifier                        as collation_schema,
       co.collname::information_schema.sql_identifier                        as collation_name,
       null::integer::information_schema.cardinal_number                     as numeric_precision,
       null::integer::information_schema.cardinal_number                     as numeric_precision_radix,
       null::integer::information_schema.cardinal_number                     as numeric_scale,
       null::integer::information_schema.cardinal_number                     as datetime_precision,
       null::character varying::information_schema.character_data            as interval_type,
       null::integer::information_schema.cardinal_number                     as interval_precision,
       current_database()::information_schema.sql_identifier                 as udt_catalog,
       nbt.nspname::information_schema.sql_identifier                        as udt_schema,
       bt.typname::information_schema.sql_identifier                         as udt_name,
       null::name::information_schema.sql_identifier                         as scope_catalog,
       null::name::information_schema.sql_identifier                         as scope_schema,
       null::name::information_schema.sql_identifier                         as scope_name,
       null::integer::information_schema.cardinal_number                     as maximum_cardinality,
       ('a'::text || x.objdtdid::text)::information_schema.sql_identifier    as dtd_identifier
from pg_namespace n,
     pg_type at,
     pg_namespace nbt,
     pg_type bt,
     ( select c.relnamespace,
              c.relname::information_schema.sql_identifier                                            as relname,
              case when c.relkind = 'c'::"char" then 'USER-DEFINED TYPE'::text else 'TABLE'::text end as "case",
              a.attnum,
              a.atttypid,
              a.attcollation
       from pg_class c,
            pg_attribute a
       where c.oid = a.attrelid
         and (c.relkind = any (array ['r'::"char", 'v'::"char", 'f'::"char", 'c'::"char", 'p'::"char"]))
         and a.attnum > 0
         and not a.attisdropped
       union all
       select t.typnamespace,
              t.typname::information_schema.sql_identifier as typname,
              'DOMAIN'::text                               as text,
              1,
              t.typbasetype,
              t.typcollation
       from pg_type t
       where t.typtype = 'd'::"char"
       union all
       select ss.pronamespace,
              nameconcatoid(ss.proname, ss.oid)::information_schema.sql_identifier as nameconcatoid,
              'ROUTINE'::text                                                      as text,
              (ss.x).n                                                             as n,
              (ss.x).x                                                             as x,
              0
       from ( select p.pronamespace,
                     p.proname,
                     p.oid,
                     information_schema._pg_expandarray(coalesce(p.proallargtypes, p.proargtypes::oid[])) as x
              from pg_proc p ) ss
       union all
       select p.pronamespace,
              nameconcatoid(p.proname, p.oid)::information_schema.sql_identifier as nameconcatoid,
              'ROUTINE'::text                                                    as text,
              0,
              p.prorettype,
              0
       from pg_proc p ) x(objschema, objname, objtype, objdtdid, objtypeid, objcollation)
         left join ( pg_collation co join pg_namespace nco on co.collnamespace = nco.oid )
                   on x.objcollation = co.oid and (nco.nspname <> 'pg_catalog'::name or co.collname <> 'default'::name)
where n.oid = x.objschema
  and at.oid = x.objtypeid
  and at.typelem <> 0::oid
  and at.typlen = '-1'::integer
  and at.typelem = bt.oid
  and nbt.oid = bt.typnamespace
  and ((n.nspname, x.objname::name, x.objtype, x.objdtdid::information_schema.sql_identifier::name) in
       ( select data_type_privileges.object_schema,
                data_type_privileges.object_name,
                data_type_privileges.object_type,
                data_type_privileges.dtd_identifier
         from information_schema.data_type_privileges ));

alter table element_types
    owner to postgres;

grant select on element_types to public;

