create view information_schema_catalog_name(catalog_name) as
select current_database()::information_schema.sql_identifier as catalog_name;

alter table information_schema_catalog_name
    owner to postgres;

grant select on information_schema_catalog_name to public;

