create view routine_routine_usage
            (specific_catalog, specific_schema, specific_name, routine_catalog, routine_schema, routine_name) as
select distinct current_database()::information_schema.sql_identifier                as specific_catalog,
                np.nspname::information_schema.sql_identifier                        as specific_schema,
                nameconcatoid(p.proname, p.oid)::information_schema.sql_identifier   as specific_name,
                current_database()::information_schema.sql_identifier                as routine_catalog,
                np1.nspname::information_schema.sql_identifier                       as routine_schema,
                nameconcatoid(p1.proname, p1.oid)::information_schema.sql_identifier as routine_name
from pg_namespace np,
     pg_proc p,
     pg_depend d,
     pg_proc p1,
     pg_namespace np1
where np.oid = p.pronamespace
  and p.oid = d.objid
  and d.classid = 'pg_proc'::regclass::oid
  and d.refobjid = p1.oid
  and d.refclassid = 'pg_proc'::regclass::oid
  and p1.pronamespace = np1.oid
  and (p.prokind = any (array ['f'::"char", 'p'::"char"]))
  and (p1.prokind = any (array ['f'::"char", 'p'::"char"]))
  and pg_has_role(p1.proowner, 'USAGE'::text);

alter table routine_routine_usage
    owner to postgres;

grant select on routine_routine_usage to public;

