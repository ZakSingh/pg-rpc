create view pg_config(name, setting) as
select name, setting
from pg_config() pg_config(name, setting);

alter table pg_config
    owner to postgres;

