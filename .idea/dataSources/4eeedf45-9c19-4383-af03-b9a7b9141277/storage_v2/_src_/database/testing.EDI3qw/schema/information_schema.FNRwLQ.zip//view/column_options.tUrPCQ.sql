create view column_options (table_catalog, table_schema, table_name, column_name, option_name, option_value) as
select current_database()::information_schema.sql_identifier                                as table_catalog,
       nspname::information_schema.sql_identifier                                           as table_schema,
       relname::information_schema.sql_identifier                                           as table_name,
       attname::information_schema.sql_identifier                                           as column_name,
       (pg_options_to_table(attfdwoptions)).option_name::information_schema.sql_identifier  as option_name,
       (pg_options_to_table(attfdwoptions)).option_value::information_schema.character_data as option_value
from information_schema._pg_foreign_table_columns c;

alter table column_options
    owner to postgres;

grant select on column_options to public;

