create view constraint_table_usage
            (table_catalog, table_schema, table_name, constraint_catalog, constraint_schema, constraint_name) as
select current_database()::information_schema.sql_identifier as table_catalog,
       nr.nspname::information_schema.sql_identifier         as table_schema,
       r.relname::information_schema.sql_identifier          as table_name,
       current_database()::information_schema.sql_identifier as constraint_catalog,
       nc.nspname::information_schema.sql_identifier         as constraint_schema,
       c.conname::information_schema.sql_identifier          as constraint_name
from pg_constraint c,
     pg_namespace nc,
     pg_class r,
     pg_namespace nr
where c.connamespace = nc.oid
  and r.relnamespace = nr.oid
  and (c.contype = 'f'::"char" and c.confrelid = r.oid or
       (c.contype = any (array ['p'::"char", 'u'::"char"])) and c.conrelid = r.oid)
  and (r.relkind = any (array ['r'::"char", 'p'::"char"]))
  and pg_has_role(r.relowner, 'USAGE'::text);

alter table constraint_table_usage
    owner to postgres;

grant select on constraint_table_usage to public;

