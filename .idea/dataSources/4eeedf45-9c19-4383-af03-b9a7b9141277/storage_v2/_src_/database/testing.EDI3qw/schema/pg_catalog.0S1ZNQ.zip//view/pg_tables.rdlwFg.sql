create view pg_tables (schemaname, tablename, tableowner, tablespace, hasindexes, hasrules, hastriggers, rowsecurity) as
select n.nspname                   as schemaname,
       c.relname                   as tablename,
       pg_get_userbyid(c.relowner) as tableowner,
       t.spcname                   as tablespace,
       c.relhasindex               as hasindexes,
       c.relhasrules               as hasrules,
       c.relhastriggers            as hastriggers,
       c.relrowsecurity            as rowsecurity
from pg_class c
         left join pg_namespace n on n.oid = c.relnamespace
         left join pg_tablespace t on t.oid = c.reltablespace
where c.relkind = any (array ['r'::"char", 'p'::"char"]);

alter table pg_tables
    owner to postgres;

grant select on pg_tables to public;

