create view key_column_usage
            (constraint_catalog, constraint_schema, constraint_name, table_catalog, table_schema, table_name,
             column_name, ordinal_position, position_in_unique_constraint)
as
select current_database()::information_schema.sql_identifier           as constraint_catalog,
       ss.nc_nspname::information_schema.sql_identifier                as constraint_schema,
       ss.conname::information_schema.sql_identifier                   as constraint_name,
       current_database()::information_schema.sql_identifier           as table_catalog,
       ss.nr_nspname::information_schema.sql_identifier                as table_schema,
       ss.relname::information_schema.sql_identifier                   as table_name,
       a.attname::information_schema.sql_identifier                    as column_name,
       (ss.x).n::information_schema.cardinal_number                    as ordinal_position,
       case when ss.contype = 'f'::"char" then information_schema._pg_index_position(ss.conindid, ss.confkey[(ss.x).n])
            else null::integer end::information_schema.cardinal_number as position_in_unique_constraint
from pg_attribute a,
     ( select r.oid                                        as roid,
              r.relname,
              r.relowner,
              nc.nspname                                   as nc_nspname,
              nr.nspname                                   as nr_nspname,
              c.oid                                        as coid,
              c.conname,
              c.contype,
              c.conindid,
              c.confkey,
              c.confrelid,
              information_schema._pg_expandarray(c.conkey) as x
       from pg_namespace nr,
            pg_class r,
            pg_namespace nc,
            pg_constraint c
       where nr.oid = r.relnamespace
         and r.oid = c.conrelid
         and nc.oid = c.connamespace
         and (c.contype = any (array ['p'::"char", 'u'::"char", 'f'::"char"]))
         and (r.relkind = any (array ['r'::"char", 'p'::"char"]))
         and not pg_is_other_temp_schema(nr.oid) ) ss
where ss.roid = a.attrelid
  and a.attnum = (ss.x).x
  and not a.attisdropped
  and (pg_has_role(ss.relowner, 'USAGE'::text) or
       has_column_privilege(ss.roid, a.attnum, 'SELECT, INSERT, UPDATE, REFERENCES'::text));

alter table key_column_usage
    owner to postgres;

grant select on key_column_usage to public;

