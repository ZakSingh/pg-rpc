create view character_sets
            (character_set_catalog, character_set_schema, character_set_name, character_repertoire, form_of_use,
             default_collate_catalog, default_collate_schema, default_collate_name)
as
select null::name::information_schema.sql_identifier                          as character_set_catalog,
       null::name::information_schema.sql_identifier                          as character_set_schema,
       getdatabaseencoding()::information_schema.sql_identifier               as character_set_name,
       case when getdatabaseencoding() = 'UTF8'::name then 'UCS'::name
            else getdatabaseencoding() end::information_schema.sql_identifier as character_repertoire,
       getdatabaseencoding()::information_schema.sql_identifier               as form_of_use,
       current_database()::information_schema.sql_identifier                  as default_collate_catalog,
       nc.nspname::information_schema.sql_identifier                          as default_collate_schema,
       c.collname::information_schema.sql_identifier                          as default_collate_name
from pg_database d
         left join ( pg_collation c join pg_namespace nc on c.collnamespace = nc.oid )
                   on d.datcollate = c.collcollate and d.datctype = c.collctype
where d.datname = current_database()
order by (char_length(c.collname::text)) desc, c.collname
limit 1;

alter table character_sets
    owner to postgres;

grant select on character_sets to public;

