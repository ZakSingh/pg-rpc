create view table_privileges
            (grantor, grantee, table_catalog, table_schema, table_name, privilege_type, is_grantable, with_hierarchy) as
select u_grantor.rolname::information_schema.sql_identifier                                                   as grantor,
       grantee.rolname::information_schema.sql_identifier                                                     as grantee,
       current_database()::information_schema.sql_identifier                                                  as table_catalog,
       nc.nspname::information_schema.sql_identifier                                                          as table_schema,
       c.relname::information_schema.sql_identifier                                                           as table_name,
       c.prtype::information_schema.character_data                                                            as privilege_type,
       case when pg_has_role(grantee.oid, c.relowner, 'USAGE'::text) or c.grantable then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no                                                 as is_grantable,
       case when c.prtype = 'SELECT'::text then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no                                                 as with_hierarchy
from ( select pg_class.oid,
              pg_class.relname,
              pg_class.relnamespace,
              pg_class.relkind,
              pg_class.relowner,
              (aclexplode(coalesce(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).grantor        as grantor,
              (aclexplode(coalesce(pg_class.relacl,
                                   acldefault('r'::"char", pg_class.relowner)))).grantee                         as grantee,
              (aclexplode(coalesce(pg_class.relacl,
                                   acldefault('r'::"char", pg_class.relowner)))).privilege_type                  as privilege_type,
              (aclexplode(coalesce(pg_class.relacl,
                                   acldefault('r'::"char", pg_class.relowner)))).is_grantable                    as is_grantable
       from pg_class ) c(oid, relname, relnamespace, relkind, relowner, grantor, grantee, prtype, grantable),
     pg_namespace nc,
     pg_authid u_grantor,
     ( select pg_authid.oid, pg_authid.rolname
       from pg_authid
       union all
       select 0::oid as oid, 'PUBLIC'::name ) grantee(oid, rolname)
where c.relnamespace = nc.oid
  and (c.relkind = any (array ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"]))
  and c.grantee = grantee.oid
  and c.grantor = u_grantor.oid
  and (c.prtype = any
       (array ['INSERT'::text, 'SELECT'::text, 'UPDATE'::text, 'DELETE'::text, 'TRUNCATE'::text, 'REFERENCES'::text, 'TRIGGER'::text]))
  and (pg_has_role(u_grantor.oid, 'USAGE'::text) or pg_has_role(grantee.oid, 'USAGE'::text) or
       grantee.rolname = 'PUBLIC'::name);

alter table table_privileges
    owner to postgres;

grant select on table_privileges to public;

