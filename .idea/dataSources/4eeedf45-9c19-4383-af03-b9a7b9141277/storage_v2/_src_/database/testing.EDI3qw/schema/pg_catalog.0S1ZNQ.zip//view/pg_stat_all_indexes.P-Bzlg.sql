create view pg_stat_all_indexes
            (relid, indexrelid, schemaname, relname, indexrelname, idx_scan, last_idx_scan, idx_tup_read,
             idx_tup_fetch) as
select c.oid                              as relid,
       i.oid                              as indexrelid,
       n.nspname                          as schemaname,
       c.relname,
       i.relname                          as indexrelname,
       pg_stat_get_numscans(i.oid)        as idx_scan,
       pg_stat_get_lastscan(i.oid)        as last_idx_scan,
       pg_stat_get_tuples_returned(i.oid) as idx_tup_read,
       pg_stat_get_tuples_fetched(i.oid)  as idx_tup_fetch
from pg_class c
         join pg_index x on c.oid = x.indrelid
         join pg_class i on i.oid = x.indexrelid
         left join pg_namespace n on n.oid = c.relnamespace
where c.relkind = any (array ['r'::"char", 't'::"char", 'm'::"char"]);

alter table pg_stat_all_indexes
    owner to postgres;

grant select on pg_stat_all_indexes to public;

