create view pg_statio_sys_sequences(relid, schemaname, relname, blks_read, blks_hit) as
select relid, schemaname, relname, blks_read, blks_hit
from pg_statio_all_sequences
where (schemaname = any (array ['pg_catalog'::name, 'information_schema'::name]))
   or schemaname ~ '^pg_toast'::text;

alter table pg_statio_sys_sequences
    owner to postgres;

grant select on pg_statio_sys_sequences to public;

