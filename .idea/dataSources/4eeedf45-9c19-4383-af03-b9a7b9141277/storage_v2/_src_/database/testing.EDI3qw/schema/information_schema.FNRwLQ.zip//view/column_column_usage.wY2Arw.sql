create view column_column_usage (table_catalog, table_schema, table_name, column_name, dependent_column) as
select distinct current_database()::information_schema.sql_identifier as table_catalog,
                n.nspname::information_schema.sql_identifier          as table_schema,
                c.relname::information_schema.sql_identifier          as table_name,
                ac.attname::information_schema.sql_identifier         as column_name,
                ad.attname::information_schema.sql_identifier         as dependent_column
from pg_namespace n,
     pg_class c,
     pg_depend d,
     pg_attribute ac,
     pg_attribute ad,
     pg_attrdef atd
where n.oid = c.relnamespace
  and c.oid = ac.attrelid
  and c.oid = ad.attrelid
  and ac.attnum <> ad.attnum
  and ad.attrelid = atd.adrelid
  and ad.attnum = atd.adnum
  and d.classid = 'pg_attrdef'::regclass::oid
  and d.refclassid = 'pg_class'::regclass::oid
  and d.objid = atd.oid
  and d.refobjid = ac.attrelid
  and d.refobjsubid = ac.attnum
  and ad.attgenerated <> ''::"char"
  and pg_has_role(c.relowner, 'USAGE'::text);

alter table column_column_usage
    owner to postgres;

grant select on column_column_usage to public;

