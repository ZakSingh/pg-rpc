create view column_privileges
            (grantor, grantee, table_catalog, table_schema, table_name, column_name, privilege_type, is_grantable) as
select u_grantor.rolname::information_schema.sql_identifier   as grantor,
       grantee.rolname::information_schema.sql_identifier     as grantee,
       current_database()::information_schema.sql_identifier  as table_catalog,
       nc.nspname::information_schema.sql_identifier          as table_schema,
       x.relname::information_schema.sql_identifier           as table_name,
       x.attname::information_schema.sql_identifier           as column_name,
       x.prtype::information_schema.character_data            as privilege_type,
       case when pg_has_role(x.grantee, x.relowner, 'USAGE'::text) or x.grantable then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no as is_grantable
from ( select pr_c.grantor,
              pr_c.grantee,
              a.attname,
              pr_c.relname,
              pr_c.relnamespace,
              pr_c.prtype,
              pr_c.grantable,
              pr_c.relowner
       from ( select pg_class.oid,
                     pg_class.relname,
                     pg_class.relnamespace,
                     pg_class.relowner,
                     (aclexplode(coalesce(pg_class.relacl,
                                          acldefault('r'::"char", pg_class.relowner)))).grantor                       as grantor,
                     (aclexplode(coalesce(pg_class.relacl,
                                          acldefault('r'::"char", pg_class.relowner)))).grantee                       as grantee,
                     (aclexplode(coalesce(pg_class.relacl,
                                          acldefault('r'::"char", pg_class.relowner)))).privilege_type                as privilege_type,
                     (aclexplode(coalesce(pg_class.relacl,
                                          acldefault('r'::"char", pg_class.relowner)))).is_grantable                  as is_grantable
              from pg_class
              where pg_class.relkind = any (array ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"]) ) pr_c(oid,
                                                                                                               relname,
                                                                                                               relnamespace,
                                                                                                               relowner,
                                                                                                               grantor,
                                                                                                               grantee,
                                                                                                               prtype,
                                                                                                               grantable),
            pg_attribute a
       where a.attrelid = pr_c.oid
         and a.attnum > 0
         and not a.attisdropped
       union
       select pr_a.grantor,
              pr_a.grantee,
              pr_a.attname,
              c.relname,
              c.relnamespace,
              pr_a.prtype,
              pr_a.grantable,
              c.relowner
       from ( select a.attrelid,
                     a.attname,
                     (aclexplode(coalesce(a.attacl, acldefault('c'::"char", cc.relowner)))).grantor        as grantor,
                     (aclexplode(coalesce(a.attacl, acldefault('c'::"char", cc.relowner)))).grantee        as grantee,
                     (aclexplode(coalesce(a.attacl, acldefault('c'::"char", cc.relowner)))).privilege_type as privilege_type,
                     (aclexplode(coalesce(a.attacl, acldefault('c'::"char", cc.relowner)))).is_grantable   as is_grantable
              from pg_attribute a
                       join pg_class cc on a.attrelid = cc.oid
              where a.attnum > 0
                and not a.attisdropped ) pr_a(attrelid, attname, grantor, grantee, prtype, grantable),
            pg_class c
       where pr_a.attrelid = c.oid
         and (c.relkind = any (array ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"])) ) x,
     pg_namespace nc,
     pg_authid u_grantor,
     ( select pg_authid.oid, pg_authid.rolname
       from pg_authid
       union all
       select 0::oid as oid, 'PUBLIC'::name ) grantee(oid, rolname)
where x.relnamespace = nc.oid
  and x.grantee = grantee.oid
  and x.grantor = u_grantor.oid
  and (x.prtype = any (array ['INSERT'::text, 'SELECT'::text, 'UPDATE'::text, 'REFERENCES'::text]))
  and (pg_has_role(u_grantor.oid, 'USAGE'::text) or pg_has_role(grantee.oid, 'USAGE'::text) or
       grantee.rolname = 'PUBLIC'::name);

alter table column_privileges
    owner to postgres;

grant select on column_privileges to public;

