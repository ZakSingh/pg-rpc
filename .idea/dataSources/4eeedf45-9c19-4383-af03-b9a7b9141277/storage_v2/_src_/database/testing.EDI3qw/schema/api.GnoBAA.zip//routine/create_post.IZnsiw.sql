create function create_post(p_content text, p_author_id integer) returns post_with_author
    language plpgsql as
$$
declare
    result _post_with_author;
begin
    with inserted_post as (
        insert into post (author_id, content)
            values (p_author_id, p_content)
            returning post_id, content, author_id
    )
    select p.post_id, p.content, a
    into result
    from inserted_post p
        join account a on a.account_id = p.author_id;

    return result::post_with_author;
end;
$$;

alter function create_post(text, integer) owner to postgres;

