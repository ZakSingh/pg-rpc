create view triggered_update_columns
            (trigger_catalog, trigger_schema, trigger_name, event_object_catalog, event_object_schema,
             event_object_table, event_object_column)
as
select current_database()::information_schema.sql_identifier as trigger_catalog,
       n.nspname::information_schema.sql_identifier          as trigger_schema,
       t.tgname::information_schema.sql_identifier           as trigger_name,
       current_database()::information_schema.sql_identifier as event_object_catalog,
       n.nspname::information_schema.sql_identifier          as event_object_schema,
       c.relname::information_schema.sql_identifier          as event_object_table,
       a.attname::information_schema.sql_identifier          as event_object_column
from pg_namespace n,
     pg_class c,
     pg_trigger t,
     ( select ta0.tgoid, (ta0.tgat).x as tgattnum, (ta0.tgat).n as tgattpos
       from ( select pg_trigger.oid as tgoid, information_schema._pg_expandarray(pg_trigger.tgattr) as tgat
              from pg_trigger ) ta0 ) ta,
     pg_attribute a
where n.oid = c.relnamespace
  and c.oid = t.tgrelid
  and t.oid = ta.tgoid
  and a.attrelid = t.tgrelid
  and a.attnum = ta.tgattnum
  and not t.tgisinternal
  and not pg_is_other_temp_schema(n.oid)
  and (pg_has_role(c.relowner, 'USAGE'::text) or
       has_column_privilege(c.oid, a.attnum, 'INSERT, UPDATE, REFERENCES'::text));

alter table triggered_update_columns
    owner to postgres;

grant select on triggered_update_columns to public;

