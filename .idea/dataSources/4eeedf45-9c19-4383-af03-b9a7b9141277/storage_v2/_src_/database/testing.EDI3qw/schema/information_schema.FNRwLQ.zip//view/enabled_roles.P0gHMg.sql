create view enabled_roles(role_name) as
select rolname::information_schema.sql_identifier as role_name
from pg_authid a
where pg_has_role(oid, 'USAGE'::text);

alter table enabled_roles
    owner to postgres;

grant select on enabled_roles to public;

