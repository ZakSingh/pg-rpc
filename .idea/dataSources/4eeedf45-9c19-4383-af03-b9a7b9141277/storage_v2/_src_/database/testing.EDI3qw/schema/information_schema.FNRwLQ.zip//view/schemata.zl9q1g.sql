create view schemata
            (catalog_name, schema_name, schema_owner, default_character_set_catalog, default_character_set_schema,
             default_character_set_name, sql_path)
as
select current_database()::information_schema.sql_identifier      as catalog_name,
       n.nspname::information_schema.sql_identifier               as schema_name,
       u.rolname::information_schema.sql_identifier               as schema_owner,
       null::name::information_schema.sql_identifier              as default_character_set_catalog,
       null::name::information_schema.sql_identifier              as default_character_set_schema,
       null::name::information_schema.sql_identifier              as default_character_set_name,
       null::character varying::information_schema.character_data as sql_path
from pg_namespace n,
     pg_authid u
where n.nspowner = u.oid
  and (pg_has_role(n.nspowner, 'USAGE'::text) or has_schema_privilege(n.oid, 'CREATE, USAGE'::text));

alter table schemata
    owner to postgres;

grant select on schemata to public;

