create view columns
            (table_catalog, table_schema, table_name, column_name, ordinal_position, column_default, is_nullable,
             data_type, character_maximum_length, character_octet_length, numeric_precision, numeric_precision_radix,
             numeric_scale, datetime_precision, interval_type, interval_precision, character_set_catalog,
             character_set_schema, character_set_name, collation_catalog, collation_schema, collation_name,
             domain_catalog, domain_schema, domain_name, udt_catalog, udt_schema, udt_name, scope_catalog, scope_schema,
             scope_name, maximum_cardinality, dtd_identifier, is_self_referencing, is_identity, identity_generation,
             identity_start, identity_increment, identity_maximum, identity_minimum, identity_cycle, is_generated,
             generation_expression, is_updatable)
as
select current_database()::information_schema.sql_identifier                                                                           as table_catalog,
       nc.nspname::information_schema.sql_identifier                                                                                   as table_schema,
       c.relname::information_schema.sql_identifier                                                                                    as table_name,
       a.attname::information_schema.sql_identifier                                                                                    as column_name,
       a.attnum::information_schema.cardinal_number                                                                                    as ordinal_position,
       case when a.attgenerated = ''::"char" then pg_get_expr(ad.adbin, ad.adrelid)
            else null::text end::information_schema.character_data                                                                     as column_default,
       case when a.attnotnull or t.typtype = 'd'::"char" and t.typnotnull then 'NO'::text
            else 'YES'::text end::information_schema.yes_or_no                                                                         as is_nullable,
       case when t.typtype = 'd'::"char" then case when bt.typelem <> 0::oid and bt.typlen = '-1'::integer then 'ARRAY'::text
                                                   when nbt.nspname = 'pg_catalog'::name
                                                       then format_type(t.typbasetype, null::integer)
                                                   else 'USER-DEFINED'::text end
            else case when t.typelem <> 0::oid and t.typlen = '-1'::integer then 'ARRAY'::text
                      when nt.nspname = 'pg_catalog'::name then format_type(a.atttypid, null::integer)
                      else 'USER-DEFINED'::text end end::information_schema.character_data                                             as data_type,
       information_schema._pg_char_max_length(information_schema._pg_truetypid(a.*, t.*),
                                              information_schema._pg_truetypmod(a.*, t.*))::information_schema.cardinal_number         as character_maximum_length,
       information_schema._pg_char_octet_length(information_schema._pg_truetypid(a.*, t.*),
                                                information_schema._pg_truetypmod(a.*, t.*))::information_schema.cardinal_number       as character_octet_length,
       information_schema._pg_numeric_precision(information_schema._pg_truetypid(a.*, t.*),
                                                information_schema._pg_truetypmod(a.*, t.*))::information_schema.cardinal_number       as numeric_precision,
       information_schema._pg_numeric_precision_radix(information_schema._pg_truetypid(a.*, t.*),
                                                      information_schema._pg_truetypmod(a.*, t.*))::information_schema.cardinal_number as numeric_precision_radix,
       information_schema._pg_numeric_scale(information_schema._pg_truetypid(a.*, t.*),
                                            information_schema._pg_truetypmod(a.*, t.*))::information_schema.cardinal_number           as numeric_scale,
       information_schema._pg_datetime_precision(information_schema._pg_truetypid(a.*, t.*),
                                                 information_schema._pg_truetypmod(a.*, t.*))::information_schema.cardinal_number      as datetime_precision,
       information_schema._pg_interval_type(information_schema._pg_truetypid(a.*, t.*),
                                            information_schema._pg_truetypmod(a.*, t.*))::information_schema.character_data            as interval_type,
       null::integer::information_schema.cardinal_number                                                                               as interval_precision,
       null::name::information_schema.sql_identifier                                                                                   as character_set_catalog,
       null::name::information_schema.sql_identifier                                                                                   as character_set_schema,
       null::name::information_schema.sql_identifier                                                                                   as character_set_name,
       case when nco.nspname is not null then current_database()
            else null::name end::information_schema.sql_identifier                                                                     as collation_catalog,
       nco.nspname::information_schema.sql_identifier                                                                                  as collation_schema,
       co.collname::information_schema.sql_identifier                                                                                  as collation_name,
       case when t.typtype = 'd'::"char" then current_database()
            else null::name end::information_schema.sql_identifier                                                                     as domain_catalog,
       case when t.typtype = 'd'::"char" then nt.nspname else null::name end::information_schema.sql_identifier                        as domain_schema,
       case when t.typtype = 'd'::"char" then t.typname else null::name end::information_schema.sql_identifier                         as domain_name,
       current_database()::information_schema.sql_identifier                                                                           as udt_catalog,
       coalesce(nbt.nspname, nt.nspname)::information_schema.sql_identifier                                                            as udt_schema,
       coalesce(bt.typname, t.typname)::information_schema.sql_identifier                                                              as udt_name,
       null::name::information_schema.sql_identifier                                                                                   as scope_catalog,
       null::name::information_schema.sql_identifier                                                                                   as scope_schema,
       null::name::information_schema.sql_identifier                                                                                   as scope_name,
       null::integer::information_schema.cardinal_number                                                                               as maximum_cardinality,
       a.attnum::information_schema.sql_identifier                                                                                     as dtd_identifier,
       'NO'::character varying::information_schema.yes_or_no                                                                           as is_self_referencing,
       case when a.attidentity = any (array ['a'::"char", 'd'::"char"]) then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no                                                                          as is_identity,
       case a.attidentity when 'a'::"char" then 'ALWAYS'::text
                          when 'd'::"char" then 'BY DEFAULT'::text
                          else null::text end::information_schema.character_data                                                       as identity_generation,
       seq.seqstart::information_schema.character_data                                                                                 as identity_start,
       seq.seqincrement::information_schema.character_data                                                                             as identity_increment,
       seq.seqmax::information_schema.character_data                                                                                   as identity_maximum,
       seq.seqmin::information_schema.character_data                                                                                   as identity_minimum,
       case when seq.seqcycle then 'YES'::text else 'NO'::text end::information_schema.yes_or_no                                       as identity_cycle,
       case when a.attgenerated <> ''::"char" then 'ALWAYS'::text
            else 'NEVER'::text end::information_schema.character_data                                                                  as is_generated,
       case when a.attgenerated <> ''::"char" then pg_get_expr(ad.adbin, ad.adrelid)
            else null::text end::information_schema.character_data                                                                     as generation_expression,
       case when (c.relkind = any (array ['r'::"char", 'p'::"char"])) or
                 (c.relkind = any (array ['v'::"char", 'f'::"char"])) and
                 pg_column_is_updatable(c.oid::regclass, a.attnum, false) then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no                                                                          as is_updatable
from pg_attribute a
         left join pg_attrdef ad on a.attrelid = ad.adrelid and a.attnum = ad.adnum
         join ( pg_class c join pg_namespace nc on c.relnamespace = nc.oid ) on a.attrelid = c.oid
         join ( pg_type t join pg_namespace nt on t.typnamespace = nt.oid ) on a.atttypid = t.oid
         left join ( pg_type bt join pg_namespace nbt on bt.typnamespace = nbt.oid )
                   on t.typtype = 'd'::"char" and t.typbasetype = bt.oid
         left join ( pg_collation co join pg_namespace nco on co.collnamespace = nco.oid )
                   on a.attcollation = co.oid and (nco.nspname <> 'pg_catalog'::name or co.collname <> 'default'::name)
         left join ( pg_depend dep join pg_sequence seq
                     on dep.classid = 'pg_class'::regclass::oid and dep.objid = seq.seqrelid and
                        dep.deptype = 'i'::"char" )
                   on dep.refclassid = 'pg_class'::regclass::oid and dep.refobjid = c.oid and dep.refobjsubid = a.attnum
where not pg_is_other_temp_schema(nc.oid)
  and a.attnum > 0
  and not a.attisdropped
  and (c.relkind = any (array ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"]))
  and (pg_has_role(c.relowner, 'USAGE'::text) or
       has_column_privilege(c.oid, a.attnum, 'SELECT, INSERT, UPDATE, REFERENCES'::text));

alter table columns
    owner to postgres;

grant select on columns to public;

