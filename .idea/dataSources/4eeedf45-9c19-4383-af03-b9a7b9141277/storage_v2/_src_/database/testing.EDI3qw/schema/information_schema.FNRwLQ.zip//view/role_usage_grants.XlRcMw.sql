create view role_usage_grants
            (grantor, grantee, object_catalog, object_schema, object_name, object_type, privilege_type, is_grantable) as
select grantor,
       grantee,
       object_catalog,
       object_schema,
       object_name,
       object_type,
       privilege_type,
       is_grantable
from information_schema.usage_privileges
where (grantor::name in ( select enabled_roles.role_name from information_schema.enabled_roles ))
   or (grantee::name in ( select enabled_roles.role_name from information_schema.enabled_roles ));

alter table role_usage_grants
    owner to postgres;

grant select on role_usage_grants to public;

