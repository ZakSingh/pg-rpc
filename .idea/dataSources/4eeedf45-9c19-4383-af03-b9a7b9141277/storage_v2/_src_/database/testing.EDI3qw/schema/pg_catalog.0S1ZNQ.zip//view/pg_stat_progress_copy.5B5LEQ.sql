create view pg_stat_progress_copy
            (pid, datid, datname, relid, command, type, bytes_processed, bytes_total, tuples_processed, tuples_excluded,
             tuples_skipped)
as
select s.pid,
       s.datid,
       d.datname,
       s.relid,
       case s.param5 when 1 then 'COPY FROM'::text when 2 then 'COPY TO'::text else null::text end as command,
       case s.param6 when 1 then 'FILE'::text
                     when 2 then 'PROGRAM'::text
                     when 3 then 'PIPE'::text
                     when 4 then 'CALLBACK'::text
                     else null::text end                                                           as type,
       s.param1                                                                                    as bytes_processed,
       s.param2                                                                                    as bytes_total,
       s.param3                                                                                    as tuples_processed,
       s.param4                                                                                    as tuples_excluded,
       s.param7                                                                                    as tuples_skipped
from pg_stat_get_progress_info('COPY'::text) s(pid, datid, relid, param1, param2, param3, param4, param5, param6,
                                               param7, param8, param9, param10, param11, param12, param13, param14,
                                               param15, param16, param17, param18, param19, param20)
         left join pg_database d on s.datid = d.oid;

alter table pg_stat_progress_copy
    owner to postgres;

grant select on pg_stat_progress_copy to public;

