create view view_routine_usage
            (table_catalog, table_schema, table_name, specific_catalog, specific_schema, specific_name) as
select distinct current_database()::information_schema.sql_identifier              as table_catalog,
                nv.nspname::information_schema.sql_identifier                      as table_schema,
                v.relname::information_schema.sql_identifier                       as table_name,
                current_database()::information_schema.sql_identifier              as specific_catalog,
                np.nspname::information_schema.sql_identifier                      as specific_schema,
                nameconcatoid(p.proname, p.oid)::information_schema.sql_identifier as specific_name
from pg_namespace nv,
     pg_class v,
     pg_depend dv,
     pg_depend dp,
     pg_proc p,
     pg_namespace np
where nv.oid = v.relnamespace
  and v.relkind = 'v'::"char"
  and v.oid = dv.refobjid
  and dv.refclassid = 'pg_class'::regclass::oid
  and dv.classid = 'pg_rewrite'::regclass::oid
  and dv.deptype = 'i'::"char"
  and dv.objid = dp.objid
  and dp.classid = 'pg_rewrite'::regclass::oid
  and dp.refclassid = 'pg_proc'::regclass::oid
  and dp.refobjid = p.oid
  and p.pronamespace = np.oid
  and pg_has_role(p.proowner, 'USAGE'::text);

alter table view_routine_usage
    owner to postgres;

grant select on view_routine_usage to public;

