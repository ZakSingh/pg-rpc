create view udt_privileges (grantor, grantee, udt_catalog, udt_schema, udt_name, privilege_type, is_grantable) as
select u_grantor.rolname::information_schema.sql_identifier               as grantor,
       grantee.rolname::information_schema.sql_identifier                 as grantee,
       current_database()::information_schema.sql_identifier              as udt_catalog,
       n.nspname::information_schema.sql_identifier                       as udt_schema,
       t.typname::information_schema.sql_identifier                       as udt_name,
       'TYPE USAGE'::character varying::information_schema.character_data as privilege_type,
       case when pg_has_role(grantee.oid, t.typowner, 'USAGE'::text) or t.grantable then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no             as is_grantable
from ( select pg_type.oid,
              pg_type.typname,
              pg_type.typnamespace,
              pg_type.typtype,
              pg_type.typowner,
              (aclexplode(coalesce(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).grantor        as grantor,
              (aclexplode(coalesce(pg_type.typacl,
                                   acldefault('T'::"char", pg_type.typowner)))).grantee                        as grantee,
              (aclexplode(coalesce(pg_type.typacl,
                                   acldefault('T'::"char", pg_type.typowner)))).privilege_type                 as privilege_type,
              (aclexplode(coalesce(pg_type.typacl,
                                   acldefault('T'::"char", pg_type.typowner)))).is_grantable                   as is_grantable
       from pg_type ) t(oid, typname, typnamespace, typtype, typowner, grantor, grantee, prtype, grantable),
     pg_namespace n,
     pg_authid u_grantor,
     ( select pg_authid.oid, pg_authid.rolname
       from pg_authid
       union all
       select 0::oid as oid, 'PUBLIC'::name ) grantee(oid, rolname)
where t.typnamespace = n.oid
  and t.typtype = 'c'::"char"
  and t.grantee = grantee.oid
  and t.grantor = u_grantor.oid
  and t.prtype = 'USAGE'::text
  and (pg_has_role(u_grantor.oid, 'USAGE'::text) or pg_has_role(grantee.oid, 'USAGE'::text) or
       grantee.rolname = 'PUBLIC'::name);

alter table udt_privileges
    owner to postgres;

grant select on udt_privileges to public;

