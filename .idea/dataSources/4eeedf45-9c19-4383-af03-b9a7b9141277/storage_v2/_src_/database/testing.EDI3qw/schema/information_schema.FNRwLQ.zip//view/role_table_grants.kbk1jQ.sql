create view role_table_grants
            (grantor, grantee, table_catalog, table_schema, table_name, privilege_type, is_grantable, with_hierarchy) as
select grantor,
       grantee,
       table_catalog,
       table_schema,
       table_name,
       privilege_type,
       is_grantable,
       with_hierarchy
from information_schema.table_privileges
where (grantor::name in ( select enabled_roles.role_name from information_schema.enabled_roles ))
   or (grantee::name in ( select enabled_roles.role_name from information_schema.enabled_roles ));

alter table role_table_grants
    owner to postgres;

grant select on role_table_grants to public;

