create view domain_constraints
            (constraint_catalog, constraint_schema, constraint_name, domain_catalog, domain_schema, domain_name,
             is_deferrable, initially_deferred)
as
select current_database()::information_schema.sql_identifier                                          as constraint_catalog,
       rs.nspname::information_schema.sql_identifier                                                  as constraint_schema,
       con.conname::information_schema.sql_identifier                                                 as constraint_name,
       current_database()::information_schema.sql_identifier                                          as domain_catalog,
       n.nspname::information_schema.sql_identifier                                                   as domain_schema,
       t.typname::information_schema.sql_identifier                                                   as domain_name,
       case when con.condeferrable then 'YES'::text else 'NO'::text end::information_schema.yes_or_no as is_deferrable,
       case when con.condeferred then 'YES'::text else 'NO'::text end::information_schema.yes_or_no   as initially_deferred
from pg_namespace rs,
     pg_namespace n,
     pg_constraint con,
     pg_type t
where rs.oid = con.connamespace
  and n.oid = t.typnamespace
  and t.oid = con.contypid
  and (pg_has_role(t.typowner, 'USAGE'::text) or has_type_privilege(t.oid, 'USAGE'::text));

alter table domain_constraints
    owner to postgres;

grant select on domain_constraints to public;

