create view referential_constraints
            (constraint_catalog, constraint_schema, constraint_name, unique_constraint_catalog,
             unique_constraint_schema, unique_constraint_name, match_option, update_rule, delete_rule)
as
select current_database()::information_schema.sql_identifier                                                         as constraint_catalog,
       ncon.nspname::information_schema.sql_identifier                                                               as constraint_schema,
       con.conname::information_schema.sql_identifier                                                                as constraint_name,
       case when npkc.nspname is null then null::name
            else current_database() end::information_schema.sql_identifier                                           as unique_constraint_catalog,
       npkc.nspname::information_schema.sql_identifier                                                               as unique_constraint_schema,
       pkc.conname::information_schema.sql_identifier                                                                as unique_constraint_name,
       case con.confmatchtype when 'f'::"char" then 'FULL'::text
                              when 'p'::"char" then 'PARTIAL'::text
                              when 's'::"char" then 'NONE'::text
                              else null::text end::information_schema.character_data                                 as match_option,
       case con.confupdtype when 'c'::"char" then 'CASCADE'::text
                            when 'n'::"char" then 'SET NULL'::text
                            when 'd'::"char" then 'SET DEFAULT'::text
                            when 'r'::"char" then 'RESTRICT'::text
                            when 'a'::"char" then 'NO ACTION'::text
                            else null::text end::information_schema.character_data                                   as update_rule,
       case con.confdeltype when 'c'::"char" then 'CASCADE'::text
                            when 'n'::"char" then 'SET NULL'::text
                            when 'd'::"char" then 'SET DEFAULT'::text
                            when 'r'::"char" then 'RESTRICT'::text
                            when 'a'::"char" then 'NO ACTION'::text
                            else null::text end::information_schema.character_data                                   as delete_rule
from pg_namespace ncon
         join pg_constraint con on ncon.oid = con.connamespace
         join pg_class c on con.conrelid = c.oid and con.contype = 'f'::"char"
         left join pg_depend d1 on d1.objid = con.oid and d1.classid = 'pg_constraint'::regclass::oid and
                                   d1.refclassid = 'pg_class'::regclass::oid and d1.refobjsubid = 0
         left join pg_depend d2
                   on d2.refclassid = 'pg_constraint'::regclass::oid and d2.classid = 'pg_class'::regclass::oid and
                      d2.objid = d1.refobjid and d2.objsubid = 0 and d2.deptype = 'i'::"char"
         left join pg_constraint pkc
                   on pkc.oid = d2.refobjid and (pkc.contype = any (array ['p'::"char", 'u'::"char"])) and
                      pkc.conrelid = con.confrelid
         left join pg_namespace npkc on pkc.connamespace = npkc.oid
where pg_has_role(c.relowner, 'USAGE'::text)
   or has_table_privilege(c.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::text)
   or has_any_column_privilege(c.oid, 'INSERT, UPDATE, REFERENCES'::text);

alter table referential_constraints
    owner to postgres;

grant select on referential_constraints to public;

