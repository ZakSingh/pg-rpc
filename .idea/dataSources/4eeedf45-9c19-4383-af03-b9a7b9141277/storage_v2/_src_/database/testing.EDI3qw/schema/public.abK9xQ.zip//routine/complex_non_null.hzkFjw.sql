create function complex_non_null() returns integer
    language plpgsql as
$$
BEGIN
    IF random() > 0.5 THEN
        RETURN 1;
    ELSE
        RETURN 2;
    END IF;
END;
$$;

alter function complex_non_null() owner to postgres;

