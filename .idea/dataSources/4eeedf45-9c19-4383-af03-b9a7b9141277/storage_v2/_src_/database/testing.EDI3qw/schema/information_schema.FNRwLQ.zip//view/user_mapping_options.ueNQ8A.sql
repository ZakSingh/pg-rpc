create view user_mapping_options
            (authorization_identifier, foreign_server_catalog, foreign_server_name, option_name, option_value) as
select um.authorization_identifier,
       um.foreign_server_catalog,
       um.foreign_server_name,
       opts.option_name::information_schema.sql_identifier         as option_name,
       case when um.umuser <> 0::oid and um.authorization_identifier::name = current_user or
                 um.umuser = 0::oid and pg_has_role(um.srvowner::name, 'USAGE'::text) or
                 ( select pg_authid.rolsuper from pg_authid where pg_authid.rolname = current_user )
                then opts.option_value
            else null::text end::information_schema.character_data as option_value
from information_schema._pg_user_mappings um,
     lateral pg_options_to_table(um.umoptions) opts(option_name, option_value);

alter table user_mapping_options
    owner to postgres;

grant select on user_mapping_options to public;

