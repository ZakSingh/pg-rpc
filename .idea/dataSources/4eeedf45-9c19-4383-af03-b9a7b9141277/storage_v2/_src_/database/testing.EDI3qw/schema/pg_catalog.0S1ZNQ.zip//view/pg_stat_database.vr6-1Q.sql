create view pg_stat_database
            (datid, datname, numbackends, xact_commit, xact_rollback, blks_read, blks_hit, tup_returned, tup_fetched,
             tup_inserted, tup_updated, tup_deleted, conflicts, temp_files, temp_bytes, deadlocks, checksum_failures,
             checksum_last_failure, blk_read_time, blk_write_time, session_time, active_time, idle_in_transaction_time,
             sessions, sessions_abandoned, sessions_fatal, sessions_killed, stats_reset)
as
select oid                                                                    as datid,
       datname,
       case when oid = 0::oid then 0 else pg_stat_get_db_numbackends(oid) end as numbackends,
       pg_stat_get_db_xact_commit(oid)                                        as xact_commit,
       pg_stat_get_db_xact_rollback(oid)                                      as xact_rollback,
       pg_stat_get_db_blocks_fetched(oid) - pg_stat_get_db_blocks_hit(oid)    as blks_read,
       pg_stat_get_db_blocks_hit(oid)                                         as blks_hit,
       pg_stat_get_db_tuples_returned(oid)                                    as tup_returned,
       pg_stat_get_db_tuples_fetched(oid)                                     as tup_fetched,
       pg_stat_get_db_tuples_inserted(oid)                                    as tup_inserted,
       pg_stat_get_db_tuples_updated(oid)                                     as tup_updated,
       pg_stat_get_db_tuples_deleted(oid)                                     as tup_deleted,
       pg_stat_get_db_conflict_all(oid)                                       as conflicts,
       pg_stat_get_db_temp_files(oid)                                         as temp_files,
       pg_stat_get_db_temp_bytes(oid)                                         as temp_bytes,
       pg_stat_get_db_deadlocks(oid)                                          as deadlocks,
       pg_stat_get_db_checksum_failures(oid)                                  as checksum_failures,
       pg_stat_get_db_checksum_last_failure(oid)                              as checksum_last_failure,
       pg_stat_get_db_blk_read_time(oid)                                      as blk_read_time,
       pg_stat_get_db_blk_write_time(oid)                                     as blk_write_time,
       pg_stat_get_db_session_time(oid)                                       as session_time,
       pg_stat_get_db_active_time(oid)                                        as active_time,
       pg_stat_get_db_idle_in_transaction_time(oid)                           as idle_in_transaction_time,
       pg_stat_get_db_sessions(oid)                                           as sessions,
       pg_stat_get_db_sessions_abandoned(oid)                                 as sessions_abandoned,
       pg_stat_get_db_sessions_fatal(oid)                                     as sessions_fatal,
       pg_stat_get_db_sessions_killed(oid)                                    as sessions_killed,
       pg_stat_get_db_stat_reset_time(oid)                                    as stats_reset
from ( select 0 as oid, null::name as datname
       union all
       select pg_database.oid, pg_database.datname
       from pg_database ) d;

alter table pg_stat_database
    owner to postgres;

grant select on pg_stat_database to public;

