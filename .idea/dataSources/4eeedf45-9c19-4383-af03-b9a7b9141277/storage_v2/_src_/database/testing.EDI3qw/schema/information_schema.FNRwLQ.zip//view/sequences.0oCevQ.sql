create view sequences
            (sequence_catalog, sequence_schema, sequence_name, data_type, numeric_precision, numeric_precision_radix,
             numeric_scale, start_value, minimum_value, maximum_value, increment, cycle_option)
as
select current_database()::information_schema.sql_identifier                                                   as sequence_catalog,
       nc.nspname::information_schema.sql_identifier                                                           as sequence_schema,
       c.relname::information_schema.sql_identifier                                                            as sequence_name,
       format_type(s.seqtypid, null::integer)::information_schema.character_data                               as data_type,
       information_schema._pg_numeric_precision(s.seqtypid, '-1'::integer)::information_schema.cardinal_number as numeric_precision,
       2::information_schema.cardinal_number                                                                   as numeric_precision_radix,
       0::information_schema.cardinal_number                                                                   as numeric_scale,
       s.seqstart::information_schema.character_data                                                           as start_value,
       s.seqmin::information_schema.character_data                                                             as minimum_value,
       s.seqmax::information_schema.character_data                                                             as maximum_value,
       s.seqincrement::information_schema.character_data                                                       as increment,
       case when s.seqcycle then 'YES'::text else 'NO'::text end::information_schema.yes_or_no                 as cycle_option
from pg_namespace nc,
     pg_class c,
     pg_sequence s
where c.relnamespace = nc.oid
  and c.relkind = 'S'::"char"
  and not (exists ( select 1
                    from pg_depend
                    where pg_depend.classid = 'pg_class'::regclass::oid
                      and pg_depend.objid = c.oid
                      and pg_depend.deptype = 'i'::"char" ))
  and not pg_is_other_temp_schema(nc.oid)
  and c.oid = s.seqrelid
  and (pg_has_role(c.relowner, 'USAGE'::text) or has_sequence_privilege(c.oid, 'SELECT, UPDATE, USAGE'::text));

alter table sequences
    owner to postgres;

grant select on sequences to public;

