create view _pg_foreign_table_columns(nspname, relname, attname, attfdwoptions) as
select n.nspname, c.relname, a.attname, a.attfdwoptions
from pg_foreign_table t,
     pg_authid u,
     pg_namespace n,
     pg_class c,
     pg_attribute a
where u.oid = c.relowner
  and (pg_has_role(c.relowner, 'USAGE'::text) or
       has_column_privilege(c.oid, a.attnum, 'SELECT, INSERT, UPDATE, REFERENCES'::text))
  and n.oid = c.relnamespace
  and c.oid = t.ftrelid
  and c.relkind = 'f'::"char"
  and a.attrelid = c.oid
  and a.attnum > 0;

alter table _pg_foreign_table_columns
    owner to postgres;

