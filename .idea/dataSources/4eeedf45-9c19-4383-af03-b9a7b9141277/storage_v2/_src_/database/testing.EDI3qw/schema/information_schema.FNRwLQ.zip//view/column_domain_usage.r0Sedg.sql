create view column_domain_usage
            (domain_catalog, domain_schema, domain_name, table_catalog, table_schema, table_name, column_name) as
select current_database()::information_schema.sql_identifier as domain_catalog,
       nt.nspname::information_schema.sql_identifier         as domain_schema,
       t.typname::information_schema.sql_identifier          as domain_name,
       current_database()::information_schema.sql_identifier as table_catalog,
       nc.nspname::information_schema.sql_identifier         as table_schema,
       c.relname::information_schema.sql_identifier          as table_name,
       a.attname::information_schema.sql_identifier          as column_name
from pg_type t,
     pg_namespace nt,
     pg_class c,
     pg_namespace nc,
     pg_attribute a
where t.typnamespace = nt.oid
  and c.relnamespace = nc.oid
  and a.attrelid = c.oid
  and a.atttypid = t.oid
  and t.typtype = 'd'::"char"
  and (c.relkind = any (array ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"]))
  and a.attnum > 0
  and not a.attisdropped
  and pg_has_role(t.typowner, 'USAGE'::text);

alter table column_domain_usage
    owner to postgres;

grant select on column_domain_usage to public;

