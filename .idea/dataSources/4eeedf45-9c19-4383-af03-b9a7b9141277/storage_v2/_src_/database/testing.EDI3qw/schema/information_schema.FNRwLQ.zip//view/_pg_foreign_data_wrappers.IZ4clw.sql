create view _pg_foreign_data_wrappers
            (oid, fdwowner, fdwoptions, foreign_data_wrapper_catalog, foreign_data_wrapper_name,
             authorization_identifier, foreign_data_wrapper_language)
as
select w.oid,
       w.fdwowner,
       w.fdwoptions,
       current_database()::information_schema.sql_identifier     as foreign_data_wrapper_catalog,
       w.fdwname::information_schema.sql_identifier              as foreign_data_wrapper_name,
       u.rolname::information_schema.sql_identifier              as authorization_identifier,
       'c'::character varying::information_schema.character_data as foreign_data_wrapper_language
from pg_foreign_data_wrapper w,
     pg_authid u
where u.oid = w.fdwowner
  and (pg_has_role(w.fdwowner, 'USAGE'::text) or has_foreign_data_wrapper_privilege(w.oid, 'USAGE'::text));

alter table _pg_foreign_data_wrappers
    owner to postgres;

