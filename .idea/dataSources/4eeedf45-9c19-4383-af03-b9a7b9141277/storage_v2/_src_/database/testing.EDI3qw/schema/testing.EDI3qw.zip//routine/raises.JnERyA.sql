create function raises() returns void
    language plpgsql as
$$
    declare
        raised int;
begin
        insert into testing.test_tbl (title, test_tbl_2_id) values ('Test', 1);
    select * from testing.test_tbl into raised;
end;
$$;

alter function raises() owner to postgres;

