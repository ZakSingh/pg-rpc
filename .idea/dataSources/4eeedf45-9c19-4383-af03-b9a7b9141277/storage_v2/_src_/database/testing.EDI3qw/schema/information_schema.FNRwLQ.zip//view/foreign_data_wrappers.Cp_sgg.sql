create view foreign_data_wrappers
            (foreign_data_wrapper_catalog, foreign_data_wrapper_name, authorization_identifier, library_name,
             foreign_data_wrapper_language)
as
select foreign_data_wrapper_catalog,
       foreign_data_wrapper_name,
       authorization_identifier,
       null::character varying::information_schema.character_data as library_name,
       foreign_data_wrapper_language
from information_schema._pg_foreign_data_wrappers w;

alter table foreign_data_wrappers
    owner to postgres;

grant select on foreign_data_wrappers to public;

