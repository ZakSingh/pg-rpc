create view check_constraints(constraint_catalog, constraint_schema, constraint_name, check_clause) as
select current_database()::information_schema.sql_identifier                               as constraint_catalog,
       rs.nspname::information_schema.sql_identifier                                       as constraint_schema,
       con.conname::information_schema.sql_identifier                                      as constraint_name,
       pg_get_expr(con.conbin, coalesce(c.oid, 0::oid))::information_schema.character_data as check_clause
from pg_constraint con
         left join pg_namespace rs on rs.oid = con.connamespace
         left join pg_class c on c.oid = con.conrelid
         left join pg_type t on t.oid = con.contypid
where pg_has_role(coalesce(c.relowner, t.typowner), 'USAGE'::text)
  and con.contype = 'c'::"char"
union
select current_database()::information_schema.sql_identifier                                                  as constraint_catalog,
       rs.nspname::information_schema.sql_identifier                                                          as constraint_schema,
       con.conname::information_schema.sql_identifier                                                         as constraint_name,
       format('%s IS NOT NULL'::text,
              coalesce(at.attname, 'VALUE'::name))::information_schema.character_data                         as check_clause
from pg_constraint con
         left join pg_namespace rs on rs.oid = con.connamespace
         left join pg_class c on c.oid = con.conrelid
         left join pg_type t on t.oid = con.contypid
         left join pg_attribute at on con.conrelid = at.attrelid and con.conkey[1] = at.attnum
where pg_has_role(coalesce(c.relowner, t.typowner), 'USAGE'::text)
  and con.contype = 'n'::"char"
union
select current_database()::information_schema.sql_identifier                        as constraint_catalog,
       n.nspname::information_schema.sql_identifier                                 as constraint_schema,
       (((((n.oid::text || '_'::text) || r.oid::text) || '_'::text) || a.attnum::text) ||
        '_not_null'::text)::information_schema.sql_identifier                       as constraint_name,
       (a.attname::text || ' IS NOT NULL'::text)::information_schema.character_data as check_clause
from pg_namespace n,
     pg_class r,
     pg_attribute a
where n.oid = r.relnamespace
  and r.oid = a.attrelid
  and a.attnum > 0
  and not a.attisdropped
  and a.attnotnull
  and (r.relkind = any (array ['r'::"char", 'p'::"char"]))
  and pg_has_role(r.relowner, 'USAGE'::text);

alter table check_constraints
    owner to postgres;

grant select on check_constraints to public;

