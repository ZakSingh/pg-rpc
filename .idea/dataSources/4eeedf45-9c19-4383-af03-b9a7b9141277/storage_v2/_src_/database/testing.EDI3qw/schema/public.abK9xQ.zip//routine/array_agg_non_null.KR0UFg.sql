create function array_agg_non_null(anyarray) returns anyarray
    immutable
    language sql as
$$
SELECT COALESCE(array_agg(value), '{}')
FROM unnest($1) AS value
WHERE value IS NOT NULL;
$$;

alter function array_agg_non_null(anyarray) owner to postgres;

