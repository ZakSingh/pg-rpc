create view data_type_privileges (object_catalog, object_schema, object_name, object_type, dtd_identifier) as
select current_database()::information_schema.sql_identifier as object_catalog,
       objschema                                             as object_schema,
       objname                                               as object_name,
       objtype::information_schema.character_data            as object_type,
       objdtdid                                              as dtd_identifier
from ( select attributes.udt_schema, attributes.udt_name, 'USER-DEFINED TYPE'::text as text, attributes.dtd_identifier
       from information_schema.attributes
       union all
       select columns.table_schema, columns.table_name, 'TABLE'::text as text, columns.dtd_identifier
       from information_schema.columns
       union all
       select domains.domain_schema, domains.domain_name, 'DOMAIN'::text as text, domains.dtd_identifier
       from information_schema.domains
       union all
       select parameters.specific_schema, parameters.specific_name, 'ROUTINE'::text as text, parameters.dtd_identifier
       from information_schema.parameters
       union all
       select routines.specific_schema, routines.specific_name, 'ROUTINE'::text as text, routines.dtd_identifier
       from information_schema.routines ) x(objschema, objname, objtype, objdtdid);

alter table data_type_privileges
    owner to postgres;

grant select on data_type_privileges to public;

