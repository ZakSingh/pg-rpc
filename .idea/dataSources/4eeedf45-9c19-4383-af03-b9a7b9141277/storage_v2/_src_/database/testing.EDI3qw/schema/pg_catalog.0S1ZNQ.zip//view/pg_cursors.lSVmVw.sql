create view pg_cursors(name, statement, is_holdable, is_binary, is_scrollable, creation_time) as
select name, statement, is_holdable, is_binary, is_scrollable, creation_time
from pg_cursor() c(name, statement, is_holdable, is_binary, is_scrollable, creation_time);

alter table pg_cursors
    owner to postgres;

grant select on pg_cursors to public;

