create view pg_stat_progress_create_index
            (pid, datid, datname, relid, index_relid, command, phase, lockers_total, lockers_done, current_locker_pid,
             blocks_total, blocks_done, tuples_total, tuples_done, partitions_total, partitions_done)
as
select s.pid,
       s.datid,
       d.datname,
       s.relid,
       s.param7::oid                      as index_relid,
       case s.param1 when 1 then 'CREATE INDEX'::text
                     when 2 then 'CREATE INDEX CONCURRENTLY'::text
                     when 3 then 'REINDEX'::text
                     when 4 then 'REINDEX CONCURRENTLY'::text
                     else null::text end  as command,
       case s.param10 when 0 then 'initializing'::text
                      when 1 then 'waiting for writers before build'::text
                      when 2 then 'building index'::text ||
                                  coalesce(': '::text || pg_indexam_progress_phasename(s.param9::oid, s.param11),
                                           ''::text)
                      when 3 then 'waiting for writers before validation'::text
                      when 4 then 'index validation: scanning index'::text
                      when 5 then 'index validation: sorting tuples'::text
                      when 6 then 'index validation: scanning table'::text
                      when 7 then 'waiting for old snapshots'::text
                      when 8 then 'waiting for readers before marking dead'::text
                      when 9 then 'waiting for readers before dropping'::text
                      else null::text end as phase,
       s.param4                           as lockers_total,
       s.param5                           as lockers_done,
       s.param6                           as current_locker_pid,
       s.param16                          as blocks_total,
       s.param17                          as blocks_done,
       s.param12                          as tuples_total,
       s.param13                          as tuples_done,
       s.param14                          as partitions_total,
       s.param15                          as partitions_done
from pg_stat_get_progress_info('CREATE INDEX'::text) s(pid, datid, relid, param1, param2, param3, param4, param5,
                                                       param6, param7, param8, param9, param10, param11, param12,
                                                       param13, param14, param15, param16, param17, param18, param19,
                                                       param20)
         left join pg_database d on s.datid = d.oid;

alter table pg_stat_progress_create_index
    owner to postgres;

grant select on pg_stat_progress_create_index to public;

