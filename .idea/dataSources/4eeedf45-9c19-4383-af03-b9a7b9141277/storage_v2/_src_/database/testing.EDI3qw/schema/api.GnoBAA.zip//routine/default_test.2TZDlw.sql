create function default_test(required boolean, optional integer DEFAULT NULL::integer) returns integer
    language plpgsql as
$$
begin
    return 1;
end;
$$;

alter function default_test(boolean, integer) owner to postgres;

