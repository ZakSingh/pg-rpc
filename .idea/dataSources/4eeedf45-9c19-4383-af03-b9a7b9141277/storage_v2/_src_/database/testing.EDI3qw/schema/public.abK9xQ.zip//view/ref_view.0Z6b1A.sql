create view ref_view(id, non, nu) as
select id, non, nu
from ref_test;

alter table ref_view
    owner to postgres;

