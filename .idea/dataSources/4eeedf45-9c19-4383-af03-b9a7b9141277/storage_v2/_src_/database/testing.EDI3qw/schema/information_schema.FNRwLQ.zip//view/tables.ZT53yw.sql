create view tables
            (table_catalog, table_schema, table_name, table_type, self_referencing_column_name, reference_generation,
             user_defined_type_catalog, user_defined_type_schema, user_defined_type_name, is_insertable_into, is_typed,
             commit_action)
as
select current_database()::information_schema.sql_identifier                                                          as table_catalog,
       nc.nspname::information_schema.sql_identifier                                                                  as table_schema,
       c.relname::information_schema.sql_identifier                                                                   as table_name,
       case when nc.oid = pg_my_temp_schema() then 'LOCAL TEMPORARY'::text
            when c.relkind = any (array ['r'::"char", 'p'::"char"]) then 'BASE TABLE'::text
            when c.relkind = 'v'::"char" then 'VIEW'::text
            when c.relkind = 'f'::"char" then 'FOREIGN'::text
            else null::text end::information_schema.character_data                                                    as table_type,
       null::name::information_schema.sql_identifier                                                                  as self_referencing_column_name,
       null::character varying::information_schema.character_data                                                     as reference_generation,
       case when t.typname is not null then current_database()
            else null::name end::information_schema.sql_identifier                                                    as user_defined_type_catalog,
       nt.nspname::information_schema.sql_identifier                                                                  as user_defined_type_schema,
       t.typname::information_schema.sql_identifier                                                                   as user_defined_type_name,
       case when (c.relkind = any (array ['r'::"char", 'p'::"char"])) or
                 (c.relkind = any (array ['v'::"char", 'f'::"char"])) and
                 (pg_relation_is_updatable(c.oid::regclass, false) & 8) = 8 then 'YES'::text
            else 'NO'::text end::information_schema.yes_or_no                                                         as is_insertable_into,
       case when t.typname is not null then 'YES'::text else 'NO'::text end::information_schema.yes_or_no             as is_typed,
       null::character varying::information_schema.character_data                                                     as commit_action
from pg_namespace nc
         join pg_class c on nc.oid = c.relnamespace
         left join ( pg_type t join pg_namespace nt on t.typnamespace = nt.oid ) on c.reloftype = t.oid
where (c.relkind = any (array ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"]))
  and not pg_is_other_temp_schema(nc.oid)
  and (pg_has_role(c.relowner, 'USAGE'::text) or
       has_table_privilege(c.oid, 'SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::text) or
       has_any_column_privilege(c.oid, 'SELECT, INSERT, UPDATE, REFERENCES'::text));

alter table tables
    owner to postgres;

grant select on tables to public;

