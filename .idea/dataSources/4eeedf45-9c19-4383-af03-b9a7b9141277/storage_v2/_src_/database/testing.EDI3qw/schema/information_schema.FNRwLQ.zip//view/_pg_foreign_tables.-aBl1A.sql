create view _pg_foreign_tables
            (foreign_table_catalog, foreign_table_schema, foreign_table_name, ftoptions, foreign_server_catalog,
             foreign_server_name, authorization_identifier)
as
select current_database()::information_schema.sql_identifier as foreign_table_catalog,
       n.nspname::information_schema.sql_identifier          as foreign_table_schema,
       c.relname::information_schema.sql_identifier          as foreign_table_name,
       t.ftoptions,
       current_database()::information_schema.sql_identifier as foreign_server_catalog,
       s.srvname::information_schema.sql_identifier          as foreign_server_name,
       u.rolname::information_schema.sql_identifier          as authorization_identifier
from pg_foreign_table t,
     pg_foreign_server s,
     pg_foreign_data_wrapper w,
     pg_authid u,
     pg_namespace n,
     pg_class c
where w.oid = s.srvfdw
  and u.oid = c.relowner
  and (pg_has_role(c.relowner, 'USAGE'::text) or
       has_table_privilege(c.oid, 'SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::text) or
       has_any_column_privilege(c.oid, 'SELECT, INSERT, UPDATE, REFERENCES'::text))
  and n.oid = c.relnamespace
  and c.oid = t.ftrelid
  and c.relkind = 'f'::"char"
  and s.oid = t.ftserver;

alter table _pg_foreign_tables
    owner to postgres;

