create function returns_null(p_account_id integer) returns account
    language plpgsql as
$$
begin
    return null;
end;
$$;

alter function returns_null(integer) owner to postgres;

