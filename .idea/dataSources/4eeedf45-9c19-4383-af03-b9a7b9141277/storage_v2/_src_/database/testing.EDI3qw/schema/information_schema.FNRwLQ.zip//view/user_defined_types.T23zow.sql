create view user_defined_types
            (user_defined_type_catalog, user_defined_type_schema, user_defined_type_name, user_defined_type_category,
             is_instantiable, is_final, ordering_form, ordering_category, ordering_routine_catalog,
             ordering_routine_schema, ordering_routine_name, reference_type, data_type, character_maximum_length,
             character_octet_length, character_set_catalog, character_set_schema, character_set_name, collation_catalog,
             collation_schema, collation_name, numeric_precision, numeric_precision_radix, numeric_scale,
             datetime_precision, interval_type, interval_precision, source_dtd_identifier, ref_dtd_identifier)
as
select current_database()::information_schema.sql_identifier              as user_defined_type_catalog,
       n.nspname::information_schema.sql_identifier                       as user_defined_type_schema,
       c.relname::information_schema.sql_identifier                       as user_defined_type_name,
       'STRUCTURED'::character varying::information_schema.character_data as user_defined_type_category,
       'YES'::character varying::information_schema.yes_or_no             as is_instantiable,
       null::character varying::information_schema.yes_or_no              as is_final,
       null::character varying::information_schema.character_data         as ordering_form,
       null::character varying::information_schema.character_data         as ordering_category,
       null::name::information_schema.sql_identifier                      as ordering_routine_catalog,
       null::name::information_schema.sql_identifier                      as ordering_routine_schema,
       null::name::information_schema.sql_identifier                      as ordering_routine_name,
       null::character varying::information_schema.character_data         as reference_type,
       null::character varying::information_schema.character_data         as data_type,
       null::integer::information_schema.cardinal_number                  as character_maximum_length,
       null::integer::information_schema.cardinal_number                  as character_octet_length,
       null::name::information_schema.sql_identifier                      as character_set_catalog,
       null::name::information_schema.sql_identifier                      as character_set_schema,
       null::name::information_schema.sql_identifier                      as character_set_name,
       null::name::information_schema.sql_identifier                      as collation_catalog,
       null::name::information_schema.sql_identifier                      as collation_schema,
       null::name::information_schema.sql_identifier                      as collation_name,
       null::integer::information_schema.cardinal_number                  as numeric_precision,
       null::integer::information_schema.cardinal_number                  as numeric_precision_radix,
       null::integer::information_schema.cardinal_number                  as numeric_scale,
       null::integer::information_schema.cardinal_number                  as datetime_precision,
       null::character varying::information_schema.character_data         as interval_type,
       null::integer::information_schema.cardinal_number                  as interval_precision,
       null::name::information_schema.sql_identifier                      as source_dtd_identifier,
       null::name::information_schema.sql_identifier                      as ref_dtd_identifier
from pg_namespace n,
     pg_class c,
     pg_type t
where n.oid = c.relnamespace
  and t.typrelid = c.oid
  and c.relkind = 'c'::"char"
  and (pg_has_role(t.typowner, 'USAGE'::text) or has_type_privilege(t.oid, 'USAGE'::text));

alter table user_defined_types
    owner to postgres;

grant select on user_defined_types to public;

