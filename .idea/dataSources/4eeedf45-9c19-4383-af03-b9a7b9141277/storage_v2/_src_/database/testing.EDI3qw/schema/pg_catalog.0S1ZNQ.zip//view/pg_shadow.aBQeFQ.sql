create view pg_shadow (usename, usesysid, usecreatedb, usesuper, userepl, usebypassrls, passwd, valuntil, useconfig) as
select pg_authid.rolname        as usename,
       pg_authid.oid            as usesysid,
       pg_authid.rolcreatedb    as usecreatedb,
       pg_authid.rolsuper       as usesuper,
       pg_authid.rolreplication as userepl,
       pg_authid.rolbypassrls   as usebypassrls,
       pg_authid.rolpassword    as passwd,
       pg_authid.rolvaliduntil  as valuntil,
       s.setconfig              as useconfig
from pg_authid
         left join pg_db_role_setting s on pg_authid.oid = s.setrole and s.setdatabase = 0::oid
where pg_authid.rolcanlogin;

alter table pg_shadow
    owner to postgres;

