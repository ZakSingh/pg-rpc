create view routine_table_usage
            (specific_catalog, specific_schema, specific_name, routine_catalog, routine_schema, routine_name,
             table_catalog, table_schema, table_name)
as
select distinct current_database()::information_schema.sql_identifier              as specific_catalog,
                np.nspname::information_schema.sql_identifier                      as specific_schema,
                nameconcatoid(p.proname, p.oid)::information_schema.sql_identifier as specific_name,
                current_database()::information_schema.sql_identifier              as routine_catalog,
                np.nspname::information_schema.sql_identifier                      as routine_schema,
                p.proname::information_schema.sql_identifier                       as routine_name,
                current_database()::information_schema.sql_identifier              as table_catalog,
                nt.nspname::information_schema.sql_identifier                      as table_schema,
                t.relname::information_schema.sql_identifier                       as table_name
from pg_namespace np,
     pg_proc p,
     pg_depend d,
     pg_class t,
     pg_namespace nt
where np.oid = p.pronamespace
  and p.oid = d.objid
  and d.classid = 'pg_proc'::regclass::oid
  and d.refobjid = t.oid
  and d.refclassid = 'pg_class'::regclass::oid
  and t.relnamespace = nt.oid
  and (t.relkind = any (array ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"]))
  and pg_has_role(t.relowner, 'USAGE'::text);

alter table routine_table_usage
    owner to postgres;

grant select on routine_table_usage to public;

