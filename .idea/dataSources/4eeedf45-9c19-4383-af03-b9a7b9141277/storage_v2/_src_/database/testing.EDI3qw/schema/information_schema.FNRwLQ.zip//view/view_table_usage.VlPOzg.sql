create view view_table_usage (view_catalog, view_schema, view_name, table_catalog, table_schema, table_name) as
select distinct current_database()::information_schema.sql_identifier as view_catalog,
                nv.nspname::information_schema.sql_identifier         as view_schema,
                v.relname::information_schema.sql_identifier          as view_name,
                current_database()::information_schema.sql_identifier as table_catalog,
                nt.nspname::information_schema.sql_identifier         as table_schema,
                t.relname::information_schema.sql_identifier          as table_name
from pg_namespace nv,
     pg_class v,
     pg_depend dv,
     pg_depend dt,
     pg_class t,
     pg_namespace nt
where nv.oid = v.relnamespace
  and v.relkind = 'v'::"char"
  and v.oid = dv.refobjid
  and dv.refclassid = 'pg_class'::regclass::oid
  and dv.classid = 'pg_rewrite'::regclass::oid
  and dv.deptype = 'i'::"char"
  and dv.objid = dt.objid
  and dv.refobjid <> dt.refobjid
  and dt.classid = 'pg_rewrite'::regclass::oid
  and dt.refclassid = 'pg_class'::regclass::oid
  and dt.refobjid = t.oid
  and t.relnamespace = nt.oid
  and (t.relkind = any (array ['r'::"char", 'v'::"char", 'f'::"char", 'p'::"char"]))
  and pg_has_role(t.relowner, 'USAGE'::text);

alter table view_table_usage
    owner to postgres;

grant select on view_table_usage to public;

